
//CS 2413 - Project 2

#include <locale>  
#include <sstream>
#include <cmath>
#include <string>
#include <list>
#include <algorithm>
#include <iterator>
#include <vector>
#include <iostream>

using namespace std;


typedef struct AST *pNODE;
struct AST {
	string info;
	pNODE children[2];
};
struct inference {
	vector<AST> premises;
	AST conclusion;
};

void Insert(string s, list<string> *L);
list<string> vars(AST T);
list<string> vars(vector<AST> Ts);
list<bool> bits(int i, int N);
AST substitute(list<bool> vals, list<string> vars, AST Exp);
bool witnessInvalid(list<bool> vals, list<string> vars, inference I);
bool valid(inference I);
string validInference(string s);
//Probably not needed..
list<string> vectToList(vector<string> V);


//********* From Project 1 *********
struct tokRslt { bool success; vector<string> syms; };
struct parseRslt { bool success; inference I; };
tokRslt tokenize(string s);
parseRslt parse(vector<string> V);
struct TPERslt { bool val; string msg; };
//********* Helpers for parse *********
//pNODE Inference(vector<string> V, int i, int j);
pNODE Expression(vector<string> V, int i, int j);
pNODE Implcation(vector<string> V, int i, int j);
pNODE Disjunction(vector<string> V, int i, int j);
pNODE Conjunction(vector<string> V, int i, int j);
pNODE Negation(vector<string> V, int i, int j);
pNODE Constant(vector<string> V, int i, int j);
pNODE Unbreakable(vector<string> V, int i, int j);
pNODE LVAR(vector<string> V, int i, int j);
pNODE Ps(vector<string> V, int i, int j);
pNODE Ps2(vector<string> V, int i, int j);
pNODE Inf(vector<string> V, int i, int j);
//********* End of helpers *********
string ASTtoString(AST T) //converts an AST to String
{
	string s;
	// If both children are NULL, just print the symbol
	if (T.children[0] == NULL) {
		s = s + T.info;
		return s;
	}

	// print an opening paren, followed by the symbol of T, followed
	// by a space, and then the first child.
	s = s + "(";
	s = s + T.info;
	s = s + " ";
	s += ASTtoString(*(T.children[0]));
	s = s + " ";

	// print the second child if there is one, and then a right paren.
	if (T.children[1] != NULL) {
		s += ASTtoString(*(T.children[1]));
	}
	s = s + ")";
	return s;
}
pNODE cons(string s, pNODE c1, pNODE c2) {
	pNODE ret = new AST;
	ret->info = s;  // same as (*ret).info = s
	ret->children[0] = c1;
	ret->children[1] = c2;
	return ret;
}
void prinTree(AST T)
{

	// If both children are NULL, just print the symbol
	if (T.children[0] == NULL) {
		cout << T.info;
		return;
	}

	// print an opening paren, followed by the symbol of T, followed
	// by a space, and then the first child.
	cout << "(" << T.info << " ";
	prinTree(*(T.children[0]));
	cout << " ";

	// print the second child if there is one, and then a right paren.
	if (T.children[1] != NULL)
		prinTree(*(T.children[1]));
	cout << ")";
}
void printList(list<string> R) {
	list<string>::const_iterator iterator;
	for (iterator = R.begin(); iterator != R.end(); iterator++) {
		cout << *iterator << ",";
	}
	cout << endl;
}
list<string> vectToList(vector<string> V) {
	list<string> L;
	for (size_t i = 0; i < V.size(); i++) {
		L.push_back(V[i]);
	}
	return L;
}
bool eval(AST T);

pNODE ASTpushAST(AST T) {
	pNODE hold = NULL, holder0 = NULL, holder1 = NULL;

	if (T.info != "\0") {
		if (T.children[0] != NULL) {
			holder0 = ASTpushAST(*T.children[0]);
		}

		if (T.children[1] != NULL) {
			holder1 = ASTpushAST(*T.children[1]);
		}
	}
	return hold = cons(T.info, holder0, holder1);
}

//**********************************
bool isSymbol(string v);
void Insert(string s, list<string> *L);
bool isSymbol(string v) {
	return (v == "T" || v == "F" || v == ":." || v == "(" || v == ")" || v == "=>" || v == "<=>" || v == "~" || v == "^" || v == "v" || v == "," || v == "<" || v == ">" || v == "=");
}
bool isSymbolChar(char v) {
	return (v == 'T' || v == 'F' || v == ':.' || v == '(' || v == ')' || v == '=>' || v == '<=>' || v == '~' || v == '^' || v == 'v' || v == ',' || v == '<' || v == '>' || v == '=');
}

tokRslt tokenize(string s) {
	tokRslt lex;
	string n;
	string c;
	int strLength = s.length();

	if (strLength == 1) {
		if (s == " ") {
			lex.syms.push_back("");
			lex.success = false;
			return lex;
		}
	}
	else if (s == "") {
		lex.syms.push_back("");
		lex.success = false;
		return lex;
	}

	for (int i = 0; i < strLength; i++) {
		n = "";
		n = n + s[i];
		c = s.substr(i,1);
		//:.
		if (s[i] == ',') {
			lex.syms.push_back(",");
			lex.success = true;
			//i++;
		}

		else if (s[i] == ':') {
			if (s[i + 1] == '.') {
				i++;
				lex.syms.push_back(":.");
				lex.success = true;
			}
			else {
				lex.syms.push_back(n);
				lex.success = false;
				break;
			}
		}
		//=>
		else if (s[i] == '=') {
			//checking next element
			if (s[i + 1] == '>') {
				i++;
				lex.syms.push_back("=>");
				lex.success = true;
			}
			else {
				lex.syms.push_back(n);
				lex.success = false;
				break;
			}
		}
		//<=>
		else if (s[i] == '<') {
			if (s[i + 1] == '='&&s[i + 2] == '>') {
				i = i + 2;
				lex.syms.push_back("<=>");
				lex.success = true;
			}
			else {
				lex.syms.push_back(n);
				lex.success = false;
				break;
			}
		}
		//T
		else if (s[i] == 'T') {
			lex.syms.push_back("T");
			lex.success = true;
			//i++;
		}
		//F
		else if (s[i] == 'F') {
			lex.syms.push_back("F");
			lex.success = true;
			//	i++;
		}
		//~
		else if (s[i] == '~') {
			lex.syms.push_back("~");
			lex.success = true;
			//i++;
		}
		//^
		else if (s[i] == '^') {
			lex.syms.push_back("^");
			lex.success = true;
			//i++;
		}
		//v
		else if (s[i] == 'v') {
			lex.syms.push_back("v");
			lex.success = true;
			//	i++;
		}
		//(
		else if (s[i] == '(') {
			lex.syms.push_back("(");
			lex.success = true;
			//	i++;
		}
		//)
		else if (s[i] == ')') {
			lex.syms.push_back(")");
			lex.success = true;
			//	i++;
		}
		else if (s[i] == ' ') {
			//do nothing
		}
		else if (islower(s[i]) && s[i] != 'v') {
			int j = i;
			string t;
			while (j < s.length() && islower(s[j]) && !isSymbol(&s[j])) {
				j = j + 1;
			}
			for (int p = i; p < j; p++) {
				t.push_back(s[p]);
			}

			i = i + t.length() - 1;
			lex.syms.push_back(t);
			lex.success = true;
		}
		else if (isupper(s[i])) {
			lex.syms.push_back(c);
			lex.success = false;
			break;
		}
	}//end of main for loop

	return lex;
}

parseRslt parse(vector<string> V) {
	parseRslt rslt;
	int i = 0;//start of V
	int j = V.size();//size of V
	int commaCount = 0;
	int locpos = 0;
	int infCount = 0;
	bool inf = false;
	rslt.success = true;

	for (int k = 0; k < j; k++) {
		if (V[k] == ":.") {
			locpos = k;
			infCount++;
			if (infCount > 1) {
				rslt.success = false;
				return rslt;
			}
			inf = true;
		}
	}

	if (inf) {
		for (int h = 0; h < locpos; h++) {
			if (V[h] == ",") {
				commaCount++;
				//inf = true;
			}
		}
	}
	else if (!inf) {
		for (int h = 0; h < j; h++) {
			if (V[h] == ",") {
				commaCount++;
				//inf = true;
			}
		}
	}

	if (commaCount > 0 && !inf) {
		rslt.success = false;
		return rslt;
	}
	if (locpos + 1 == j) {
		rslt.success = false;
		return rslt;
	}

	if (commaCount == 0) {
		if (inf) {
			pNODE ip = Inf(V, i, locpos);
			pNODE ps = Ps2(V, locpos + 1, j);
			if (ip == NULL || ps == NULL) {
				rslt.success = false;
				return rslt;
			}
			else {

				rslt.I.premises.push_back(*ps);
				rslt.I.conclusion = *ip;
				rslt.success = true;
				return rslt;
			}
			/*
			if (A.info == "" || A.children[0] == NULL) {

				rslt.success = false;
				return rslt;
			}

				rslt.success = true;
				return rslt;

			*/
		}
		else if (!inf) {
			pNODE A = Expression(V, i, j);
			if (A != NULL) {
				prinTree(*A);
				rslt.I.premises.push_back(*A);
				rslt.success = true;
				return rslt;
			}
			else {
				rslt.success = false;
				return rslt;
			}

		}

	}

	//if (commaCount != 0) {

	if (commaCount == 1) {
		for (int c = i; c < j; c++) {
			if (V[c] == ",") {

				pNODE partA = Inf(V, i, c);
				if (partA == NULL) {
					rslt.success = false;
					return rslt;
				}
				pNODE partB = Inf(V, c + 1, locpos);
				if (partB == NULL) {
					rslt.success = false;
					return rslt;
				}
				
				rslt.I.premises.push_back(*partA);
				rslt.I.premises.push_back(*partB);
			}
			
		}
	}

	

			
		
		if (commaCount == 2) {

			for (int c = i; c < j; c++) {

				if (V[c] == ",") {
					for (int k = c + 1; k < j; k++) {
						if (V[k] == ",") {

							//if (a.children[0] == NULL && a.children[1] == NULL) {
								//rslt.success = false;
							pNODE partA = Inf(V, i, c);
							pNODE partB = Inf(V, c + 1, k);
							pNODE partC = Inf(V, k + 1, locpos);
							if (partA == NULL || partB == NULL || partC == NULL) {
								rslt.success = false;
								return rslt;
							}
							rslt.I.premises.push_back(*partA);
							rslt.I.premises.push_back(*partB);
							rslt.I.premises.push_back(*partC);
						}
					}

				}
			}
		}
		if (commaCount == 3) {
			for (int c = i; c < j; c++) {
				if (V[c] == ",") {
					for (int k = c + 1; k < j; k++) {
						if (V[k] == ",") {
							for (int a = k + 1; a < j; a++) {
								if (V[a] == ",") {
									pNODE partA = Inf(V, i, c);
									pNODE partB = Inf(V, c + 1, k);
									pNODE partC = Inf(V, k + 1, a);
									pNODE partD = Inf(V, a + 1, locpos);
									if (partA == NULL || partB == NULL || partC == NULL || partD == NULL) {
										rslt.success = false;
										return rslt;
									}
									rslt.I.premises.push_back(*partA);
									rslt.I.premises.push_back(*partB);
									rslt.I.premises.push_back(*partC);
									rslt.I.premises.push_back(*partD);
								}
							}


						}
					}

				}
			}
		}
		if (commaCount == 4) {
			for (int c = i; c < j; c++) {
				if (V[c] == ",") {
					for (int k = c + 1; k < j; k++) {
						if (V[k] == ",") {
							for (int a = k + 1; a < j; a++) {
								if (V[a] == ",") {
									for (int b = a + 1; b < j; b++) {
										if (V[b] == ",") {
											pNODE partA = Inf(V, i, c);
											pNODE partB = Inf(V, c + 1, k);
											pNODE partC = Inf(V, k + 1, a);
											pNODE partD = Inf(V, a + 1, b);
											pNODE partE = Inf(V, b + 1, locpos);
											if (partA == NULL || partB == NULL || partC == NULL || partD == NULL || partE == NULL) {
												rslt.success = false;
												return rslt;
											}
											rslt.I.premises.push_back(*partA);
											rslt.I.premises.push_back(*partB);
											rslt.I.premises.push_back(*partC);
											rslt.I.premises.push_back(*partD);
											rslt.I.premises.push_back(*partE);
										}
									}
								}
							}


						}
					}

				}
			}
		}
		if (commaCount == 5) {
			for (int c = i; c < j; c++) {
				if (V[c] == ",") {
					for (int k = c + 1; k < j; k++) {
						if (V[k] == ",") {
							for (int a = k + 1; a < j; a++) {
								if (V[a] == ",") {
									for (int b = a + 1; b < j; b++) {
										if (V[b] == ",") {
											for (int g = b + 1; g < j; g++) {
												if (V[g] == ",") {
													pNODE partA = Inf(V, i, c);
													pNODE partB = Inf(V, c + 1, k);
													pNODE partC = Inf(V, k + 1, a);
													pNODE partD = Inf(V, a + 1, b);
													pNODE partE = Inf(V, b + 1, g);
													pNODE partF = Inf(V, g + 1, locpos);
													if (partA == NULL || partB == NULL || partC == NULL || partD == NULL || partE == NULL || partF == NULL) {
														rslt.success = false;
														return rslt;
													}
													rslt.I.premises.push_back(*partA);
													rslt.I.premises.push_back(*partB);
													rslt.I.premises.push_back(*partC);
													rslt.I.premises.push_back(*partD);
													rslt.I.premises.push_back(*partE);
													rslt.I.premises.push_back(*partF);
												}
											}
										}
									}
								}
							}


						}
					}

				}
			}
		}
		if (commaCount == 6) {
			for (int c = i; c < j; c++) {
				if (V[c] == ",") {
					for (int k = c + 1; k < j; k++) {
						if (V[k] == ",") {
							for (int a = k + 1; a < j; a++) {
								if (V[a] == ",") {
									for (int b = a + 1; b < j; b++) {
										if (V[b] == ",") {
											for (int g = b + 1; g < j; g++) {
												if (V[g] == ",") {
													for (int m = g + 1; m < j; m++) {
														if (V[m] == ",") {
															pNODE partA = Inf(V, i, c);
															pNODE partB = Inf(V, c + 1, k);
															pNODE partC = Inf(V, k + 1, a);
															pNODE partD = Inf(V, a + 1, b);
															pNODE partE = Inf(V, b + 1, g);
															pNODE partF = Inf(V, g + 1, m);
															pNODE partG = Inf(V, m + 1, locpos);
															if (partA == NULL || partB == NULL || partC == NULL || partD == NULL || partE == NULL || partF == NULL || partG == NULL) {
																rslt.success = false;
																return rslt;
															}
															rslt.I.premises.push_back(*partA);
															rslt.I.premises.push_back(*partB);
															rslt.I.premises.push_back(*partC);
															rslt.I.premises.push_back(*partD);
															rslt.I.premises.push_back(*partE);
															rslt.I.premises.push_back(*partF);
															rslt.I.premises.push_back(*partG);
														}
													}
												}
											}
										}
									}
								}
							}


						}
					}

				}
			}
		}
		if (commaCount == 7) {
			for (int c = i; c < j; c++) {
				if (V[c] == ",") {
					for (int k = c + 1; k < j; k++) {
						if (V[k] == ",") {
							for (int a = k + 1; a < j; a++) {
								if (V[a] == ",") {
									for (int b = a + 1; b < j; b++) {
										if (V[b] == ",") {
											for (int g = b + 1; g < j; g++) {
												if (V[g] == ",") {
													for (int m = g + 1; m < j; m++) {
														if (V[m] == ",") {
															for (int n = m + 1; n < j; n++) {
																if (V[n] == ",") {
																	pNODE partA = Inf(V, i, c);
																	pNODE partB = Inf(V, c + 1, k);
																	pNODE partC = Inf(V, k + 1, a);
																	pNODE partD = Inf(V, a + 1, b);
																	pNODE partE = Inf(V, b + 1, g);
																	pNODE partF = Inf(V, g + 1, m);
																	pNODE partG = Inf(V, m + 1, n);
																	pNODE partH = Inf(V, n + 1, locpos);
																	if (partA == NULL || partB == NULL || partC == NULL || partD == NULL || partE == NULL || partF == NULL || partG == NULL || partH == NULL) {
																		rslt.success = false;
																		return rslt;
																	}
																	rslt.I.premises.push_back(*partA);
																	rslt.I.premises.push_back(*partB);
																	rslt.I.premises.push_back(*partC);
																	rslt.I.premises.push_back(*partD);
																	rslt.I.premises.push_back(*partE);
																	rslt.I.premises.push_back(*partF);
																	rslt.I.premises.push_back(*partG);
																	rslt.I.premises.push_back(*partH);
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}


						}
					}

				}
			}
		}
		if (commaCount == 8) {
			for (int c = i; c < j; c++) {
				if (V[c] == ",") {
					for (int k = c + 1; k < j; k++) {
						if (V[k] == ",") {
							for (int a = k + 1; a < j; a++) {
								if (V[a] == ",") {
									for (int b = a + 1; b < j; b++) {
										if (V[b] == ",") {
											for (int g = b + 1; g < j; g++) {
												if (V[g] == ",") {
													for (int m = g + 1; m < j; m++) {
														if (V[m] == ",") {
															for (int n = m + 1; n < j; n++) {
																if (V[n] == ",") {
																	for (int f = n + 1; f < j; f++) {
																		if (V[f] == ",") {
																			pNODE partA = Inf(V, i, c);
																			pNODE partB = Inf(V, c + 1, k);
																			pNODE partC = Inf(V, k + 1, a);
																			pNODE partD = Inf(V, a + 1, b);
																			pNODE partE = Inf(V, b + 1, g);
																			pNODE partF = Inf(V, g + 1, m);
																			pNODE partG = Inf(V, m + 1, n);
																			pNODE partH = Inf(V, n + 1, f);
																			pNODE partI = Inf(V, f + 1, locpos);
																			if (partA == NULL || partB == NULL || partC == NULL || partD == NULL || partE == NULL || partF == NULL || partG == NULL || partH == NULL || partI == NULL) {
																				rslt.success = false;
																				return rslt;
																			}
																			rslt.I.premises.push_back(*partA);
																			rslt.I.premises.push_back(*partB);
																			rslt.I.premises.push_back(*partC);
																			rslt.I.premises.push_back(*partD);
																			rslt.I.premises.push_back(*partE);
																			rslt.I.premises.push_back(*partF);
																			rslt.I.premises.push_back(*partG);
																			rslt.I.premises.push_back(*partH);
																			rslt.I.premises.push_back(*partI);
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}


						}
					}

				}
			}
		}
		if (commaCount == 9) {
			for (int c = i; c < j; c++) {
				if (V[c] == ",") {
					for (int k = c + 1; k < j; k++) {
						if (V[k] == ",") {
							for (int a = k + 1; a < j; a++) {
								if (V[a] == ",") {
									for (int b = a + 1; b < j; b++) {
										if (V[b] == ",") {
											for (int g = b + 1; g < j; g++) {
												if (V[g] == ",") {
													for (int m = g + 1; m < j; m++) {
														if (V[m] == ",") {
															for (int n = m + 1; n < j; n++) {
																if (V[n] == ",") {
																	for (int f = n + 1; f < j; f++) {
																		if (V[f] == ",") {
																			for (int q = f + 1; q < j; q++) {
																				if (V[q] == ",") {
																					pNODE partA = Inf(V, i, c);
																					pNODE partB = Inf(V, c + 1, k);
																					pNODE partC = Inf(V, k + 1, a);
																					pNODE partD = Inf(V, a + 1, b);
																					pNODE partE = Inf(V, b + 1, g);
																					pNODE partF = Inf(V, g + 1, m);
																					pNODE partG = Inf(V, m + 1, n);
																					pNODE partH = Inf(V, n + 1, f);
																					pNODE partI = Inf(V, f + 1, q);
																					pNODE partJ = Inf(V, q + 1, locpos);
																					if (partA == NULL || partB == NULL || partC == NULL || partD == NULL || partE == NULL || partF == NULL || partG == NULL || partH == NULL ||
																						partI == NULL || partJ == NULL) {
																						rslt.success = false;
																						return rslt;
																					}
																					rslt.I.premises.push_back(*partA);
																					rslt.I.premises.push_back(*partB);
																					rslt.I.premises.push_back(*partC);
																					rslt.I.premises.push_back(*partD);
																					rslt.I.premises.push_back(*partE);
																					rslt.I.premises.push_back(*partF);
																					rslt.I.premises.push_back(*partG);
																					rslt.I.premises.push_back(*partH);
																					rslt.I.premises.push_back(*partI);
																					rslt.I.premises.push_back(*partJ);
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}


						}
					}

				}
			}
		}
		if (commaCount == 10) {
			for (int c = i; c < j; c++) {
				if (V[c] == ",") {
					for (int k = c + 1; k < j; k++) {
						if (V[k] == ",") {
							for (int a = k + 1; a < j; a++) {
								if (V[a] == ",") {
									for (int b = a + 1; b < j; b++) {
										if (V[b] == ",") {
											for (int g = b + 1; g < j; g++) {
												if (V[g] == ",") {
													for (int m = g + 1; m < j; m++) {
														if (V[m] == ",") {
															for (int n = m + 1; n < j; n++) {
																if (V[n] == ",") {
																	for (int f = n + 1; f < j; f++) {
																		if (V[f] == ",") {
																			for (int q = f + 1; q < j; q++) {
																				if (V[q] == ",") {
																					for (int w = q + 1; w < j; w++) {
																						if (V[w] == ",") {
																							pNODE partA = Inf(V, i, c);
																							pNODE partB = Inf(V, c + 1, k);
																							pNODE partC = Inf(V, k + 1, a);
																							pNODE partD = Inf(V, a + 1, b);
																							pNODE partE = Inf(V, b + 1, g);
																							pNODE partF = Inf(V, g + 1, m);
																							pNODE partG = Inf(V, m + 1, n);
																							pNODE partH = Inf(V, n + 1, f);
																							pNODE partI = Inf(V, f + 1, q);
																							pNODE partJ = Inf(V, q + 1, w);
																							pNODE partK = Inf(V, w + 1, locpos);
																							if (partA == NULL || partB == NULL || partC == NULL || partD == NULL || partE == NULL || partF == NULL || partG == NULL || partH == NULL ||
																								partI == NULL || partJ == NULL || partK == NULL) {
																								rslt.success = false;
																								return rslt;
																							}
																							rslt.I.premises.push_back(*partA);
																							rslt.I.premises.push_back(*partB);
																							rslt.I.premises.push_back(*partC);
																							rslt.I.premises.push_back(*partD);
																							rslt.I.premises.push_back(*partE);
																							rslt.I.premises.push_back(*partF);
																							rslt.I.premises.push_back(*partG);
																							rslt.I.premises.push_back(*partH);
																							rslt.I.premises.push_back(*partI);
																							rslt.I.premises.push_back(*partJ);
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}


						}
					}

				}
			}
		}

	
		AST con = *Inf(V, locpos+1, j);
		
		AST t = con;
		
	
	
	if (t.children[0] != NULL) {
		if (t.children[1] != NULL) {
			
			rslt.I.conclusion = t;
			rslt.success = true;
			return rslt;
		}
		else {

			rslt.I.conclusion = *t.children[0];
			rslt.success = true;
			return rslt;
		}
	}

	else if (t.children[0] == NULL && t.children[1] != NULL) {
		cout << "here";
		rslt.I.conclusion = *t.children[1];
		rslt.success = true;
		return rslt;
	}
	else if (t.children[0] == NULL && t.children[1] == NULL) {

		rslt.success = false;
		return rslt;
	}
		
}

//The following are Parse helper functions:
//Checks for the following parameneters: if it is a bool expression

pNODE Expression(vector<string> V, int i, int j) {

	for (int c = i; c<j; c++) {
		if (V[c] == "<=>") {
			pNODE t1 = Implcation(V, i, c);
			pNODE t2 = Expression(V, c + 1, j);
			if (t1 != NULL && t2 != NULL)
				return cons("<=>", t1, t2);
		}
	}
	pNODE W = Implcation(V, i, j);
	if (W != NULL) {
	
		return W;
	}
	pNODE t = Unbreakable(V, i, j);
	//if the unbreakable is not null we return it
	if (t != NULL) {
		return t;
	}
	return NULL;
}

//Checks for the following parameneters: T,F
pNODE Constant(vector<string> V, int i, int j) {
	if (!(i == (j - 1)))
		return NULL;
	if (V[i] == "T" || V[i] == "F") {
		return cons(V[i], NULL, NULL);
	}
	return NULL;
}
//Checks for the following parameneters: ~
pNODE Negation(vector<string> V, int i, int j) {
	for (int c = i; c<j; c++) {
		if (V[c] == "~") {
			//	pNODE t1 = Expression(V, i ,c);
			pNODE t2 = Negation(V, i + 1, j);
			if (t2 != NULL) {

				return cons("~", t2, NULL);
			}
		}
	}
	pNODE test = Unbreakable(V, i, j);
	if (test != NULL) {
		return test;
	}
	// All attempts failed
	return NULL;
}
//Checks for the following parameneters: ^(AND)
pNODE Conjunction(vector<string> V, int i, int j) {
	for (int c = i; c<j; c++) {
		if (V[c] == "^") {
		
			pNODE t1 = Conjunction(V, i, c);
			pNODE t2 = Negation(V, c + 1, j);
			if (t1 != NULL && t2 != NULL)
				return cons("^", t1, t2);
		}
	}
	pNODE A = Negation(V, i, j);
	if (A != NULL) {
		return A;
	}

	return NULL;
}
//Checks for the following parameneters: v(OR)
pNODE Disjunction(vector<string> V, int i, int j) {
	for (int c = i; c<j; c++) {
		if (V[c] == "v") {
			pNODE t1 = Disjunction(V, i, c);
			pNODE t2 = Conjunction(V, c + 1, j);
			if (t1 != NULL && t2 != NULL)
				return cons("v", t1, t2);
		}
	}
	pNODE A = Conjunction(V, i, j);
	if (A != NULL) {
		return A;
	}
	return NULL;
}
//Checks for the following parameneters: =>(false and true is false otherwise is true)
pNODE Implcation(vector<string> V, int i, int j) {
	for (int c = i; c<j; c++) {
		if (V[c] == "=>") {
			pNODE t1 = Disjunction(V, i, c);
			pNODE t2 = Implcation(V, c + 1, j);
			if (t1 != NULL && t2 != NULL)
				return cons("=>", t1, t2);
		}
	}
	pNODE A = Disjunction(V, i, j);
	if (A != NULL) {
		return A;
	}
	return NULL;
}
pNODE Unbreakable(vector<string> V, int i, int j) {

	// U::=  "(" Expression ")"
	pNODE test = Constant(V, i, j);
	if (test != NULL) {
		return test;
	}
	else if (V[i] == "(") {
		if (V[j - 1] == ")") {
			pNODE temp = Expression(V, i + 1, j - 1);
			if (temp != NULL) {

				return temp;
			}
		}
		else {
			for (int l = i; l < j; l++) {
				if (V[l] == ")") {
					pNODE temp = Expression(V, i + 1, l - 1);
					if (temp != NULL) {
						return temp;
					}
				}
			}

		}
	}
	pNODE t9 = Constant(V, i, j);
	if (t9 != NULL) {
		
		return t9;
	}
	
	pNODE test2 = LVAR(V, i, j);
	if (test2 != NULL) {
		return test2;
	}
	// All attempts failed
	return NULL;
}
pNODE LVAR(vector<string> V, int i, int j) {
	string lex;
	string t;
	for (int c = i; c < j; c++) {
		if (!isSymbol(V[c]) && V[c] != "v") {
		
			int k = c;
			while (k < V.size() && !isSymbol(V[k])) {
				k = k + 1;
			}
			for (int p = i; p < k; p++) {
				lex = lex + V[p];
				
			}
			t = lex;
			lex = "";
		}
		i = i + lex.length();
		return cons(t, NULL, NULL);
	}
	return NULL;
}

pNODE Ps(vector<string> V, int i, int j) {
	if (i == j) {
		return NULL;
	}
	for (int c = i; c < j; c++) {
		if (V[c] == ",") {
			pNODE ps = Ps(V, i, c);
			pNODE bexp = Expression(V, c + 1, j);
			if (ps != NULL && bexp != NULL) {
				return cons(",", bexp, ps);//bexp changed in second spot
			}
		}
	}

	pNODE bexp = Expression(V, i, j);
	if (bexp != NULL) {
		return bexp;
	}

	return NULL;
}

pNODE Ps2(vector<string> V, int i, int j) {
	
		//if (V[i+1] == ":." || V[j] == ":.") {	
			
		//	return NULL;
	//	}
		if (i == j) {
			return  NULL;
		}
		
	for (int c = i; c < j; c++) {
		if (V[c] == ",") {
			pNODE ps = Ps2(V, i, c);
			pNODE bexp = Expression(V, c + 1, j);
			if (ps != NULL && bexp != NULL) {// && bexp != NULL
				return cons(",", bexp, ps);//bexp changed in second spot
			}
		}
	}

	pNODE bexp = Expression(V, i, j);
	if (bexp != NULL) {
		return bexp;
	}
	
	return NULL;
}
pNODE Inf(vector<string> V, int i, int j) {
	
	for (int c = i; c < j; c++) {
		if (V[c] == ":.") {
			pNODE ps = Ps(V, i, c);
			
			if (c + 1 == j) {
				return NULL;
			}
			pNODE bexp = Expression(V, c + 1, j);
					
			if (ps != NULL && bexp != NULL) {
				return cons(":.", bexp, ps);//ps
			}
		}
	}
	pNODE bexp = Expression(V, i, j);
	
	if (bexp != NULL) {
		return bexp;
	}
	
	return NULL;
}


//End of helpers for parse
//*************************************************************************************

//Done
void Insert(string s, list<string> *L) {
	list<string> R = *L;
	list<string>::const_iterator iterator;

	//transform(s.begin(), s.end(), s.begin(), toupper);

	bool found = (find(R.begin(), R.end(), s) != R.end());

	if (found) {
		//do nothing;
		return;
	}
	//Put s into R, sorted correctly.
	else if (!found) {
		R.push_back(s);
		R.sort();
		*L = R;
	}
}
//Done
list<string> vars(AST T) {
	list<string> temp;
	if (&T == NULL) {
		return temp;
	}
	string treeString = ASTtoString(T);
	int treeStringlength = treeString.length();
	for (int i = 0; i < treeString.length(); i++) {
		if (islower(treeString[i]) && treeString[i] != 'v') {
			string t;
			int j = i;
			while (j < treeStringlength && islower(treeString[j])) {
				j = j + 1;
			}
			for (int p = i; p < j; p++) {
				t.push_back(treeString[p]);
			}
			i = i + t.length();
			temp.push_back(t);
		}
	}
	temp.sort();
	temp.unique();
	return temp;
}
//Done
list<string> vars(vector<AST> Ts) {
	
	list<string> hold;
	list<string> temp;
	list<string>::const_iterator iterator;
	string s;
	for (int i = 0; i < Ts.size(); i++) {
		temp = vars(Ts[i]);
		for (iterator = temp.begin(); iterator != temp.end(); iterator++) {
			hold.push_back(*iterator);
		}
	}
	hold.unique();
	hold.sort();
	
	return hold;
}

//TODO: DONE
//Converts i to a binary number of N digits. 
list<bool> bits(int i, int N) {
	list<bool> numbers;
	int remainder;
	int divisor = 2;
	int currentVal = 0;
	if (N < 0 || i < 0 || i > pow(2, N) - 1) {
		return numbers;
	}
	if (N > 0) {
		if (i > 0 && (i < (pow(2, N) - 1))) {
			while (i != 0) {
				remainder = i % divisor;
				numbers.push_back(remainder);
				i = i / 2;
			}
		}
	}
	if (numbers.size()< N) {
		while (numbers.size()< N)
			numbers.push_back(0);
	}
	numbers.reverse();
	return numbers;
}

//Done
AST substitute(list<bool> vals, list<string> vars, AST Exp) {
	//Exp by substituting "T" for vars[i] whenever vals[i] = 1, and "F" for vars[i] whenever vals[i] = 0.

	list<string>::iterator strIter = vars.begin();
	list<bool>::iterator boolIter = vals.begin();
	vector<string>holder;
	
	if (vars.size() == vals.size()) {
		for (int i = 0; boolIter != vals.end(); boolIter++, i++) {
			if (!*boolIter) {
				holder.push_back("F");
			}
			else if (*boolIter) {
				holder.push_back("T");
			}
		}

		for (int i = 0; strIter != vars.end(); i++, strIter++) {
			if (*strIter == Exp.info) {
				Exp.info = holder[i];
				break;
			}
		}
		if (Exp.children[0] != NULL) {
			*Exp.children[0] = substitute(vals, vars, *Exp.children[0]);
		}

		if (Exp.children[1] != NULL) {
			*Exp.children[1] = substitute(vals, vars, *Exp.children[1]);
		}
	}

	//Otherwise returns empty if vars != vals
	return Exp;
}

//Done
bool witnessInvalid(list<bool> vals, list<string> vars, inference I) {
	int psSize = I.premises.size();
	bool found = false;
	for (int i = 0; i < psSize; i++) {
		found = eval(substitute(vals, vars, I.premises[i]));
		if (found == false) {
			return false;
		}
	}
	if (found == true && eval(substitute(vals, vars, I.conclusion))) {
		return true;
	}
	
}

bool valid(inference I) {
	bool invalid = false;
	bool found = true;
	bool Ps;
	bool conC;
	vector<AST>holder;
	holder = I.premises;
	holder.push_back(I.conclusion);
	inference reg;

	list<string>lvars = vars(holder);
	if (lvars.size() == 0) {
		for (int i = 0; i < I.premises.size(); i++) {
			Ps = eval(I.premises[i]);
			if (!Ps) {
				break;
			}
		}
		if (Ps) {
			conC = eval(I.conclusion);
		}
		else {
			return true;
		}

		if (Ps && !conC) {
			return false;
		}
		else {
			return true;
		}
	}
	for (int i = 0; i < I.premises.size(); i++){
		reg.premises.push_back(*ASTpushAST(I.premises[i]));
	}

	reg.conclusion = *ASTpushAST(I.conclusion);
	for (int j = 0; j < (pow(2, lvars.size()) - 1); j++) {
		invalid = witnessInvalid(bits(j, lvars.size()), lvars, I);
		if (invalid) {
			break;
		}
		for (int k = 0; k < I.premises.size(); k++) {
			I.premises[k] = *ASTpushAST(reg.premises[k]);
		}
		I.conclusion = *ASTpushAST(reg.conclusion);
	}

	if (invalid) {
		return false;
	}
	else if (!invalid) {
		return true;
	}
	else {
		cout << "ERROR";
	}
	return !invalid;
}
bool eval(AST T) {
	string op = T.info;
	bool temp;
	if (op == "~") {
		temp = eval(*T.children[0]);
		if (!temp) {
			return  1;
		}
		else
			return 0;
	}
	//F
	else if (op == "F") {
		return 0;
	}
	//T
	else if (op == "T") {
		return 1;
	}
	//OR
	else if (op == "v") {
		if (eval(*T.children[0]) || eval(*T.children[1])) {
			return 1;
		}
		else
			return 0;
	}
	//AND
	else if (op == "^") {
		if ((eval(*T.children[0]) && eval(*T.children[1]))) {
			return 1;
		}
		else
			return 0;
	}
	//false and true is false otherwise is true
	else if (op == "=>") {
		if (eval(*T.children[0]) && !eval(*T.children[1])) {
			return 0;
		}
		else
			return 1;
	}
	else if (op == "<=>") {
		if ((eval(*T.children[1]) == eval(*T.children[0]))) {

			return 1;
		}
		else

			return 0;
	}

	return NULL;
}

//modified for proj2
TPERslt TPE(string s) {
	TPERslt tpe;
	tokRslt tempToken;
	parseRslt tempParse;
	
	tempToken = tokenize(s);
	
	tpe.val = false;
	tempParse = parse(tempToken.syms);
	
	if (!tempToken.success) {
		tpe.msg = "symbol error";
		return tpe;
	}
	else if (!tempParse.success) {
		tpe.msg = "grammar error";
		return tpe;
	}
	else if (tempParse.success && tempToken.success) {
		tpe.msg = "success";
		tpe.val = valid(tempParse.I);
		return tpe;
	}
	return tpe;
}

string validInference(string s) {
	string outputMsg;

	if (TPE(s).msg == "success") {
		if (TPE(s).val == true) {
			outputMsg = "valid";
			return outputMsg;
		}
		else if (TPE(s).val == false) {
			outputMsg = "invalid";
			return outputMsg;
		}
	}
	else if (TPE(s).msg == "grammar error") {
		outputMsg = "grammar error";
		return outputMsg;
	}

	else if (TPE(s).msg == "symbol error") {
		outputMsg = "symbol error";
		return outputMsg;
	}

	return "FAILED";
}

//********************* TEST FUNCTIONS START HERE *****************************

void checkInsert()
{
	list<string> mylist = { "bar", "foo" };

	Insert("boo", &mylist);

	list<string> test = { "bar","boo","foo" };

	if (mylist == test) //Insert should return mylist in sorted form with new variable "boo" added
		cout << "\nINSERT Function PASSED";

	else
		cout << "\nINSERT Function FAILED";
}


//Checks list<string> vars(AST T)
void checkVars1()
{
	AST A, B, C, D, E;

	//Expression: p v q => T
	//Replace it with your own AST for your own test cases

	A = *cons("=>", &B, &C);
	B = *cons("v", &D, &E);
	C = *cons("T", NULL, NULL);
	D = *cons("p", NULL, NULL);
	E = *cons("q", NULL, NULL);

	list<string> allvars = vars(A);
	//list<string> testvars = { "p","q" }; //List of all variables that should be in AST T, in sorted order
	list<string> testvars = { "p","q" };

	if (allvars == testvars) //Insert should return mylist in sorted form with new variable "boo" added
		cout << "\nVars(AST T) PASSED";


	else
		cout << "\nVars(AST T) Failed!!";

}

//Checks list<string> vars(vector<AST> Ts)
void checkVars2()
{
	inference inf;
	AST A, B, C, D, E, R, K, P;
	A = *cons("=>", &B, &C);
	B = *cons("v", &D, &E);
	C = *cons("roo", NULL, NULL);
	D = *cons("p", NULL, NULL);
	E = *cons("q", NULL, NULL);
	inf.premises.push_back(A);
	P = *cons("=>", &R, &K);
	R = *cons("lp", NULL, NULL);
	K = *cons("yi", NULL, NULL);
	inf.premises.push_back(P);

	list<string>::const_iterator iterator;
	list<string> allvars = vars(inf.premises);

	list<string> test = { "p","q","roo","lp","yi" };   //ADD all the variables here in your premises
	test.sort();


	if (allvars == test) //Insert should return mylist in sorted form with new variable "boo" added
		cout << "\nVars(vector<AST Ts>) PASSED";


	else
		cout << "\nVars(vector<AST Ts>) Failed!!";

}

void checkBits()
{
	list<bool> num = { 1,0,0,0,0,1,0,1,1 }; //Number 267
	int i = 267;
	list<bool> test1 = bits(i, 9);
	list<bool> test2 = bits(i, 5); //should return an empty list

	if (test1 == num && test2.empty())
		cout << "\nBits ALL test cases PASSED";

	else if (test1 != num) //Correction: should have been test1 instead of test
		cout << "\nBits failed to generate sequence for number " << i;

	else
		cout << "\nBits ALL test cases Failed";

}

void checkSubstitute()
{
	AST A, B, C, D, E, F;
	//AST ~p ^ q v r
	A = *cons("v", &B, &C);
	B = *cons("^", &D, &E);
	C = *cons("r", NULL, NULL);
	D = *cons("~", &F, NULL);
	E = *cons("q", NULL, NULL);
	F = *cons("p", NULL, NULL);



	list<bool> b = { 0,0,1 }; // p=0 (F), q=0 (F), r=1 (T)
	list<string> v = { "p","q","r" };
	AST result = substitute(b, v, A);

	string output = ASTtoString(result); //Converting to string for comparison

	string subAST = "(v (^ (~ F ) F) T)"; //Correction Made

	if (output == subAST)
		cout << "\nSubstitute ALL test case passed";

	else
		cout << "\nSubstitute failed for ~p ^ q v r";
}

void  checkValidInference()
{

	string t1 = "~ p v F => (ac v ~dc), ac ^ dc :. p";  //Should evaluate to Invalid
	string t2 = "Foo V Bar, bar <=> Foo :. T";  //symbol error

	string t3 = "(ab ^ cd), cd => ~ab :. ^ cd";   //grammar error


	string op1, op2, op3;

	op1 = validInference(t1);
	op2 = validInference(t2);
	op3 = validInference(t3);

	if (op1 == "invalid" && op2 == "symbol error" && op3 == "grammar error")
		cout << "\nValid Inference all cases passed";

	else if (op1 != "invalid")
		cout << "\n Valid Inference test case " << t1 << " failed. EXPECTED: invalid, OUTPUT generated: " << op1;

	else if (op2 != "symbol error")
		cout << "\n Valid Inference test case " << t2 << " failed. EXPECTED: symbol error, OUTPUT generated: " << op2;

	else if (op3 != "grammar error")
		cout << "\n Valid Inference test case " << t3 << " failed. EXPECTED: grammar error, OUTPUT generated: " << op3;

	else
		cout << "\n Valid Inference test ALL test cases FAILED";
}


int main() {
	//checkBits(); //DONE
	//checkInsert(); //DONE
	//checkVars1(); //DONE
	//checkVars2(); //DONE
	//checkValidInference();
	//checkSubstitute();
	string s = "~ p v F => (ac v ~dc), ac ^ dc :. p";
	//string s = "(";
	tokRslt tok;
	parseRslt par;
	//tok = tokenize(s);

	/*
	for (int i = 0; i < tok.syms.size(); i++) {
	cout << tok.syms[i] << endl;
	}
	*/
	//par = parse(tok.syms);
	//prinTree(par.I.premises[0]);
	cout << validInference(s);

	return 0;
}

