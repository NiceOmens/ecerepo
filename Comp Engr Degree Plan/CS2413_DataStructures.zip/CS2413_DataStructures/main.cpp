/*

Project 1: Boolean Expression Eval 
CS2413 - 503
NOTE: The main is commented out in the bottom of the program.
NOTE: Program has test functions at the bottom commented out.
*/

#include <string>
#include <vector>
#include <algorithm>
#include <iostream>
#include <iterator>
using namespace std;

//given structs
typedef struct AST *pNODE;
struct AST { string info; pNODE children[2]; };
struct tokRslt { bool success; vector<string> syms; };
struct parseRslt { bool success; AST ast; };
struct TPERslt { bool val; string msg; };

//tests, giving random stirngs both correct and not.
//void testFunction();

//Given functions
tokRslt tokenize(string s);
parseRslt parse(vector<string> V);
bool eval(AST T);
string TPEOut(string s);

//helper functions for parse
pNODE Expression(vector<string> V, int i, int j);
pNODE Implcation(vector<string> V, int i, int j);
pNODE Disjunction(vector<string> V, int i, int j);
pNODE Conjunction(vector<string> V, int i, int j);
pNODE Negation(vector<string> V, int i, int j);
pNODE Constant(vector<string> V, int i, int j);
pNODE Unbreakable(vector<string> V, int i, int j);

//Givens by Dr. Rushton:
/*
PrinTree and cons
*/

//Prints Tree
void prinTree(AST T) {
	// If both children are NULL, just print the symbol
	if (T.children[0] == NULL) {
		cout << T.info;
		return;
	}
	cout << "(" << T.info << " ";
	prinTree(*(T.children[0]));
	cout << " ";

	if (T.children[1] != NULL)
		prinTree(*(T.children[1]));
	cout << ")";
}

pNODE cons(string s, pNODE c1, pNODE c2) {
	pNODE ret = new AST;
	ret->info = s;  // same as (*ret).info = s
	ret->children[0] = c1;
	ret->children[1] = c2;
	return ret;
}

//TODO: DONE!
tokRslt tokenize(string s) {
	tokRslt lex;
	lex.success = false;
	string n;
	for (int i = 0; s[i] != '\0'; i++) {
		if ((s[i] == 'T' || s[i] == 'F' || s[i] == '=' || s[i] == 'v' || s[i] == '<' || s[i] == '>' || s[i] == '^' || s[i] == '<=>' || s[i] == '=>' || s[i] == '~' || s[i] == '(' || s[i] == ')' || s[i] == ' ')) {

			n = "";
			n = n + s[i];
			if (s[i] == '=')
			{
				//checking next element
				if (s[i + 1] == '>') {
					i++;
					lex.syms.push_back("=>");
					lex.success = true;
				}
				else {
					lex.syms.push_back(n);
					lex.success = true;
				}
			}
			else if (s[i] == '<') {
				if (s[i + 1] == '='&&s[i + 2] == '>') {
					i = i + 2;
					lex.syms.push_back("<=>");
					lex.success = true;
				}
				else if (s[i] == 'T') {
					lex.syms.push_back("T");
					lex.success = true;
					i++;
				}
				else if (s[i] == 'F') {
					lex.syms.push_back("F");
					lex.success = true;
					i++;
				}
			}
			//For everything else
			else {
				if (s[i] != ' ') {
					lex.success = true;
					lex.syms.push_back(n);
				}
			}
		}
		else {
			lex.success = false;
			return lex;
		}
	}
	
	//passing vector to parse function
	
	return lex;
}


//TODO: DONE
parseRslt parse(vector<string> V) {
	parseRslt rslt;
	if (V.size() == 1) {
		if (V[0] == " " || V[0] == "")
			rslt.success = false;
	}
	int i = 0;//start of V
	int j = V.size();//size of V
	pNODE A = Expression(V, i, j);
	
	rslt.success = (A != NULL);
	rslt.ast = *A;
	//prinTree(rslt.ast);
	return rslt;
	
}

//The following are Parse helper functions:
//Checks for the following parameneters: if it is a bool expression
pNODE Expression(vector<string> V, int i, int j) {
	for (int c = i; c<j; c++) {
		if (V[c] == "<=>") {

			pNODE t1 = Implcation(V, i, c);
			pNODE t2 = Expression(V, c + 1, j);
			if (t1 != NULL && t2 != NULL)
				return cons("<=>", t1, t2);
		}
	}
	pNODE W = Implcation(V, i, j);
	if (W != NULL) {

		return W;

	}
	return NULL;
}
//Checks for the following parameneters: T,F
pNODE Constant(vector<string> V, int i, int j) {
	for (int c = i; c < j; c++) {
		if (V[c] == "T" || V[c] == "F") {
			return cons(V[c], NULL, NULL);
		}
	}
	return NULL;
}
//Checks for the following parameneters: ~
pNODE Negation(vector<string> V, int i, int j) {

	for (int c = i ; c<j; c++) {
		if (V[c] == "~") {
		//	pNODE t1 = Expression(V, i ,c);
			pNODE t2 = Negation(V, c+1, j);
			if (t2 != NULL) {
				
				return cons("~", t2,NULL);
			}
		}
	}
	pNODE test = Unbreakable(V, i, j);
	if (test != NULL) {
		return test;
	}
	// All attempts failed
	return NULL;
}
//Checks for the following parameneters: ^(AND)
pNODE Conjunction(vector<string> V, int i, int j) {
	
	for (int c = i; c<j; c++) {
		if (V[c] == "^") {
			pNODE t1 = Conjunction(V, i, c);
			pNODE t2 = Negation(V, c + 1, j);
			if (t1 != NULL && t2 != NULL)
				return cons("^", t1, t2);
		}
	}

	pNODE A = Negation(V, i, j);
	if (A != NULL) {

		return A;
	}
	return NULL;
}
//Checks for the following parameneters: v(OR)
pNODE Disjunction(vector<string> V, int i, int j) {
	for (int c = i ; c<j; c++) {
		if (V[c] == "v") {
			pNODE t1 = Disjunction(V, i, c);
			pNODE t2 = Conjunction(V, c + 1, j);
			if (t1 != NULL && t2 != NULL)
				return cons("v", t1, t2);
		}
	}
	pNODE A = Conjunction(V, i, j);
	if (A != NULL) {
		return A;
	}
	return NULL;
}
//Checks for the following parameneters: =>(false and true is false otherwise is true)
pNODE Implcation(vector<string> V, int i, int j) {
	for (int c = i; c<j; c++) {
		
		if (V[c] == "=>") {
			pNODE t1 = Disjunction(V, i, c);
			pNODE t2 = Implcation(V, c + 1, j);
			if (t1 != NULL && t2 != NULL)
				return cons("=>", t1, t2);
		}
	}
	pNODE A = Disjunction(V, i, j);
	if (A != NULL) {
		return A;
	}
	return NULL;
}
pNODE Unbreakable(vector<string> V, int i, int j) {
	// U::=  "(" Expression ")"
	
	
	if (V[i] == "(" && V[j] == ")") {
		pNODE temp = Expression(V, i + 1, j);
		if (temp != NULL) {
			return temp;
		}
	
	}
	pNODE test = Constant(V, i, j);
	if (test != NULL) {

		return test;
	}
	// All attempts failed
	return NULL;
}
//**************** End of Parse helper functions *************************

bool eval(AST T) {
	string op = T.info;
	bool temp;
	if (op == "~") {
		temp = eval(*T.children[0]);
		if (!temp) {
			return 1;
		}
		else
			return 0;
	}
	//F
	else if (op == "F") {
		return 0;
	}
	//T
	else if (op == "T") {
		return 1;
	}
	//OR
	else if (op == "v") {
		if (eval(*T.children[0]) || eval(*T.children[1])) {
			return 1;
		}
		else
			return 0;
	}
	//AND
	else if (op == "^") {
		if ((eval(*T.children[0]) && eval(*T.children[1]))) {
			return 1;
		}
		else
			return 0;
	}
	//false and true is false otherwise is true
	else if (op == "=>") {
		if (eval(*T.children[0]) && !eval(*T.children[1])) {
			return 0;
		}
		else
			return 1;
	}

	return NULL;
}

TPERslt TPE(string s) {
	vector<string>Rtemp;
	TPERslt tpe;
	tokRslt tempToken;
	parseRslt tempParse;
	tempToken = tokenize(s);
	Rtemp = tempToken.syms;
	tempParse = parse(Rtemp);
	if (!tempToken.success) {
		tpe.msg = "symbol error";
		return tpe;
	}
	
	else if (!tempParse.success) {
		tpe.msg = "grammar error";
		return tpe;
	}

	else if (tempParse.success && tempToken.success) {
		tpe.msg = "success";
		tpe.val = eval(tempParse.ast);
		
		return tpe;
	}
	return tpe;
}

string TPEOut(string s) {
	string outputMsg;
	
	if (TPE(s).msg == "success") {
		if (TPE(s).val == true) {
			outputMsg = "true";
			return outputMsg;
		}
		else if (TPE(s).val == false) {
			outputMsg = "false";
			return outputMsg;
		}
	}
	else if (TPE(s).msg == "grammar error") {
		outputMsg = "grammar error";
		return outputMsg;
	}

	else if (TPE(s).msg == "symbol error") {
		outputMsg = "symbol error";
		return outputMsg;
	}
	
	return "FAILED";
}


//TEST FUNCTIONS BELOW
/*
string ASTtoString(AST T) //converts an AST to String
{
	string s;
	// If both children are NULL, just print the symbol
	if (T.children[0] == NULL) {
		s = s + T.info;
		return s;
	}

	// print an opening paren, followed by the symbol of T, followed
	// by a space, and then the first child.
	s = s + "(";
	s = s + T.info;
	s = s + " ";
	s += ASTtoString(*(T.children[0]));
	s = s + " ";

	// print the second child if there is one, and then a right paren.
	if (T.children[1] != NULL) {
		s += ASTtoString(*(T.children[1]));
	}
	s = s + ")";
	return s;
}

void checkTokenize()
{
tokRslt tk1, tk2;
string s1 = "=><=>";
string s2 = "(T v F)";
vector<string> v1, v2;

tk1 = tokenize(s1);
tk2 = tokenize(s2);

if (tk1.success && tk2.success)
{
v1.push_back("=>"); //if the success value is true only then we initialize vectors v1,v2 with actual input symbols
v1.push_back("<=>");

v2.push_back("(");
v2.push_back("T");
v2.push_back("v");
v2.push_back("F");
v2.push_back(")");

if (tk1.syms == v1 && tk2.syms == v2)
cout << "\nTokenize ALL Test Cases passed";

else if (tk1.syms != v1)
{
cout << "\nTokenize Test case 1: " << s1 << " FAILED";
}

else if (tk2.syms != v2)
{
cout << "\nTokenize Test case 2: " << s2 << " FAILED";
}
else
{
cout << "\nTokenize ALL test cases FAILED";
}
}

else if (!tk1.success)
{
cout << "\nTokenize Test case 1: " << s1 << " FAILED";
}
else if (!tk2.success)
{
cout << "\nTokenize Test case 1: " << s1 << " FAILED";
}
else
{
cout << "\nTokenize ALL test cases FAILED";
}
}

void checkParse()
{
	vector<string> v1, v2;
	parseRslt pr1, pr2;

	string s1 = "T v F ^ F";
	string s2 = "~F => T";

	v1.push_back("T"); //v1 = T v F ^ F
	v1.push_back("v");
	v1.push_back("F");
	v1.push_back("^");
	v1.push_back("F");

	v2.push_back("~"); //v2 = ~F ^ T
	v2.push_back("F"); //v2 = ~F ^ T
	v2.push_back("=>");
	v2.push_back("T");



	pr1 = parse(v1);
	pr2 = parse(v2);

	if (pr1.success && pr2.success)//pr1.success && pr2.success)
	{
		string AST_case1 = "(v T (^ F F))";  //AST for v1 = T v F ^ F
		string AST_case2 = "(=> (~ F ) T)"; //AST for v2 = ~F ^ T
		string pr1_str, pr2_str;

		//Converting user AST tree to string for comparison
		pr1_str = ASTtoString(pr1.ast);
		pr2_str = ASTtoString(pr2.ast);

		if (pr1_str == AST_case1 && pr2_str == AST_case2)//pr1_str == AST_case1 && pr2_str == AST_case2)
		{
			cout << "\nParse ALL Test cases Passed";
		}

		else if (pr1_str != AST_case1)
		{
			cout << "\nParse Test case 1: " << s1 << " FAILED";
		}
		else if (pr2_str != AST_case2)
		{
			cout << "\nParse Test case 2: " << s2 << " FAILED";
		}
		else
		{
			cout << "\nParse ALL Test case FAILED";
		}
	}

	else if (!pr1.success)
	{
		cout << "\nParse Test case 1: " << s1 << " FAILED";
	}
	else if (!pr2.success)
	{
		cout << "\nParse Test case 2: " << s2 << " FAILED";
	}

	else
	{
		cout << "\n Parse ALL test cases FAILED";
	}

}

void checkEval()
{
bool ev1, ev2;
AST test1, test2, B, C, D, E, b, c, d, e;
string s1 = "T v F ^ F"; 
string s2 = "~ F ^ T";
//AST for T v F ^ F
test1 = *cons("v", &B, &C);
B = *cons("^", &D, &E);
C = *cons("T", NULL, NULL);
D = *cons("F", NULL, NULL);
E = *cons("F", NULL, NULL);


//AST for ~ F ^ T
test2 = *cons("^", &b, &c);
b = *cons("~", &d, NULL);
c = *cons("T", NULL, NULL);
d = *cons("F", NULL, NULL);


ev1 = eval(test1);
ev2 = eval(test2);

if (ev1 && ev2)
{
cout << "\nEval ALL Test cases Passed";
}
else if (!ev1)
{
cout << "\nEval Test case 1: " << s1 << " FAILED";
}
else if (!ev2)
{
cout << "\nEval Test case 2: " << s2 << " FAILED";
}
else
{
cout << "\nEval ALL test cases FAILED";
}

}

void checkTPE()
{
	
TPERslt tpe1, tpe2;
tpe1 = TPE("T => ~F"); //Should evaluate to TRUE
tpe2 = TPE("T v F * F"); //Should print "symbol error"

if (tpe1.msg == "success" && tpe2.msg == "symbol error")
{
	if (tpe1.val) //if AST evaluates to TRUE for test case 1-     T => ~F
		cout << "\nTPE ALL Test cases PASSED";
}
else if (!tpe1.val)
{
	cout << "\nTPE Test case 1: T => ~F " << " FAILED";
}
else if (tpe2.msg != "symbol error")
{
	cout << "\nTPE Test case 2: T v F * F " << " FAILED";
}
else
{
	cout << "\nTPE ALL test cases FAILED";
}
}

void checkTPEOut()
{
string t1, t2;

string case1 = "~ (~ T v F)^ F"; //Should evalute to "false"
string case2 = "(T v F) v ~ F ^ F"; //Should evalute to "true"

t1 = TPEOut(case1);
//cout << "T1: " << t1 << endl;
t2 = TPEOut(case2);
//cout << "T2: " << t2 << endl;
if (t1 == "true" && t2 == "true")
{
cout << "\nTPEOut ALL Test cases PASSED";
}
else if (t1 != "false")
{
cout << "\nTPEOut Test case 1: " << case1 << " FAILED";
}
else if (t2 != "true")
{
cout << "\nTPEOut Test case 2: " << case2 << " FAILED";
}
else
{
cout << "\nTPE ALL test cases FAILED";
}
}

int main()
{
checkTokenize();
checkParse();
checkEval();
checkTPE();
checkTPEOut();

return 0;
}
*/