
//Worked with: No one
//Course:     ECE 1305-004, spring 2017
//Assignment: Lab 01, part 3, "Finding errors and debugging a program".
//
//Description: 
//A no longer buggy program that calcules the combined resitnace of 2 resistors in parallel.

//Orginal heading:
// ECE 1305 Lab 01 buggy program intended to calculate the combined resistance of 2 resistors in parallel. 
//
//  Program with some syntax errors, the math isn't quite right, and a 
//  rather easy mistake to make in declaring the variables.
//
//Author:  Ian Scott - Fleming
//
//	Underlying Math:
//	Parallel Resistence: see "Method 2" on http://www.wikihow.com/Calculate-Series-and-Parallel-Resistance	
//	1/R-equiv = 1/R1 + 1/R2
//
//		or
//
//	R-equiv =    ____1____
//				1/R1 + 1/R2
//
//  Some correct answers:
//  R1 and R2 both 10 ohms (using first formula):  
//			1/r-equiv is 1/10 + 1/10 = 2/10, so R-equiv is 5 ohms
//  R1 is 5 ohms and R2 is 10 ohms(using 2nd formula):  
//R - equiv is 1 / (1 / 5 + 1 / 10) = 1 / (3 / 10) = 3.33333 ohms.
//-----------------------------------------------


#include <iostream>
using namespace std;
	int main(void)
{
	double r_equiv;
	float R1, R2;
	

		cout << "Program to calculate parallel resistance" << endl;

	//Prompt for resistence
		cout << "Enter R1 and R2 in ohms: ";

	//Read in resistor values.
		cin >> R1 >> R2;

	// while debugging, make sure we read in the correct resistences
	// I made a small change here adding a comma between R1 and R2 for readability!
		cout << "Resistors R1 and R2: " << R1 << "," << R2 << endl;

	// calculate the resistance:
		r_equiv = 1 / ((1 / R1) + (1 / R2));
		
		 
		cout << "Equivalent Resistance:  " << r_equiv << endl;

		return 0;
}