
//Worked with: No one
//Course:     ECE 1305-004, spring 2017
//Assignment: Lab 01, part 4, "Little siblings' dividing program"
//
//Description: 
//Computes the quotient from given values by the user. Users double for sister and int for brother and displays remainder for brother as well.

#include <iostream>
using namespace std;
#include <cstdlib>

int main() {

	//declaring variables 
	//N is the dividend
	//Q is the diviser
	//R is the remiander
	//A is the answer
	int broN;
	int broQ;
	int broA;
	int broR;

	double sisN;
	double sisQ;
	double sisA;

	//Asks the user to input the brother and sisters numbers.
	cout << "Please enter the brothers dividend and diviser, followed by the sisers seperated by spaces: ";
		cin >> broN >> broQ >> sisN >> sisQ;

	//if division by zero, display an error and end the program.
	if (broQ == 0 || sisQ == 0) {
			cout << "Division by zero error! Please enter a number greater than zero." << endl;
			exit(0);
		}

	else {
		//math
		sisA = sisN / sisQ;
		broA = broN / broQ;
		broR = broN % broQ;

		//outputs answers
		cout << "The brothers answer is: " << broN << "/" << broQ << " = " << broA << " remainder " << broR << endl;

		cout << "The brothers answer is: " << sisN << "/" << sisQ << " = " << sisA << endl;

		return 0;
	}
	
	





}
