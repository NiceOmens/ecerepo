
//Worked with: No one
//Course:     ECE 1305-004, spring 2017
//Assignment: Lab 01, part 5, "Progressive Tax calculator"
//
//Description: 
//Computes the amount paid in taxes of a given user income based on tax brackets of either, 0%, 10%, 15%, 20% or 30% based on the respected income.

#include <iostream>
using namespace std;



int main()
{
	//declares income and taxincome.
	double income;
	//set initially to 0 because visual was upset and it makes no difference as it change once in logic.
	double taxincome = 0;

	//asks for user input
	cout << "Please enter your income: ";
	cin >> income;
	//income minus 5000 as that part is tax free.
	double taxfree = income - 5000;

	//if you make less than 5000 it is tax free.
	if (income < 5000) {
		cout << "You pay nothing in taxes!";
	}
	// if you make between 5000 and 10000 you pay 10% in taxes.
	if (income > 5000 && income <= 10000) {
		taxincome = taxfree *.10;
		cout << "The amount you pay in taxes is " << "$" << taxincome << endl;
	}
	//if you make between 10k and 20k you pay 15% on your raw minus 10% of your income minus the tax free portion.
	if (income > 10000 && income <= 20000) {
		taxincome = income *.15 - taxfree *.1;
		cout << "The amount you pay in taxes is " << "$" << taxincome << endl;
	}
	//if you make between 20k and 30k you pay 20% on your raw minus 10% of your income minus the tax free portion.
	if (income > 20000 && income <= 30000) {
		taxincome = income *.20 - taxfree*.1;
		cout << "The amount you pay in taxes is " << "$" << taxincome << endl;
	}
	//if you make more than 30k you pay 30% on your raw minus 10% of your income minus the tax free portion.
	if (income > 30000) {
		//Math
		taxincome = income *.30 - taxfree*.1;
		//outputting answer with $ sign and "the amount you pay in taxes" before the value for prettiness.
		cout << "The amount you pay in taxes is " << "$" << taxincome << endl;
	}
	
	return 0;
}




