
//Worked with: No one
//Course:     ECE 1305-004, spring 2017
//Assignment: Lab 01 Challenge
//
//Description: 
//Computes the angle between two given vectors by the user.


#include <iostream>
using namespace std;
#include <cstdlib>

int main() {

	//initializing variables
	double x1;
	double y1;
	double x2;
	double y2;
	
	double angle;
	double angleD;

	//takes user input
	cout << "Please enter the x and y values for your two vectors in X Y X Y order:  ";
	cin >> x1 >> y1 >> x2 >> y2;

	//calcules the angle in radians(default)
	angle = (atan2(y2, x2) - atan2(y1, x1));
	//also did it in degrees because it was not specified which one you guys wanted.
	angleD = (atan2(y2, x2) - atan2(y1, x1)) * (180 / 3.14159265359);

	//outputs angle in radians and degrees in a clear way for user.
	cout << "The angle between the two vectors, " << "(" << x1 << "," << y1 << ")" << " and " << "(" << x2 << "," << y2 << ")," << " in radians is " << " is " << angle << " and in degrees is " << angleD << endl;





}