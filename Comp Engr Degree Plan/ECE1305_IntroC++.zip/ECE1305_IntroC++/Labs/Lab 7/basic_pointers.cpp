/*

Worked with: NAMES
Class: ECE 1305-04
4/10/2017

LAB 07, part 2.1

Description:
Takes an and values and shows the use and versatility of pointers in various situations.

*/

#include <iostream>
using namespace std;
#include <iomanip>
int main()
{
	int i = 5, j = 51, k = 62;
	int data[5] = { 10, 20, 30, 40, 50 };
	char my_cstring[8] = "the fox";

	int *p = NULL;
	char *pc = NULL;

	p = &i;
	cout << "p points to the value of i at: " << p << endl;
	p = &j;
	cout << "p points to the value of j at: " << p << endl;
	p = &k;
	cout << "p points to the value of j at: " << p << endl;
	p = data;
	cout << "p points to the value of the array data at: " << p << endl;
	p = &data[2];
	cout << "p points to the value of the array data at: " << p << endl;


	pc = &my_cstring[0];
	pc[0] = toupper(pc[0]);
	cout << "The first element in upper case is: " << pc[0] << endl;

	pc = &my_cstring[4];
	pc[0] = toupper(pc[0]);
	cout << "The fifth element in upper case is: " << pc[0] << endl;

	//for part 3.f
	pc = my_cstring;
	cout << "The char and integer forms for the my_cstring array are: " << endl;
	cout << *pc << " " << pc[0] << " " << setw(3) << static_cast<int>(*pc) << endl;
	cout << *pc << " " << pc[1] << " " << setw(3) << static_cast<int>(*pc) << endl;
	cout << *pc << " " << pc[2] << " " << setw(3) << static_cast<int>(*pc) << endl;
	cout << *pc << " " << pc[3] << " " << setw(3) << static_cast<int>(*pc) << endl;
	cout << *pc << " " << pc[4] << " " << setw(3) << static_cast<int>(*pc) << endl;
	cout << *pc << " " << pc[5] << " " << setw(3) << static_cast<int>(*pc) << endl;
	cout << *pc << " " << pc[6] << " " << setw(3) << static_cast<int>(*pc) << endl;
	cout << *pc << " " << pc[7] << " " << setw(3) << static_cast<int>(*pc) << endl;


	cout << "done" << endl;
#ifdef WIN32
	system("pause");
#endif
	return 0;
}
