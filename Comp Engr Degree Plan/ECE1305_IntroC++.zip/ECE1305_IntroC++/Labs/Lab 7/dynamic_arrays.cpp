/*

Worked with: NAMES
Class: ECE 1305-04
4/10/2017

LAB 07, part 3.1

Description:
Creates a dynaic array of given size and values from user, then deletes it.
*/

#include <iostream>
using namespace std;

//prototype calls
void print_array(int a[],int size);
void create_array(int * &p, int size, int initval);

int main() {

	int* a = NULL;
	int size = 0;
	int intval = 0;

	//gets size and initval.
	cout << "Please enter the size of the array you want: ";
	cin >> size;
	cout << endl;
	cout << "Please enter the initiate value from the array: ";
	cin >> intval;

	a = new int[size];
	//From the first part of the part 3.
	//
	//a = new int[6];
	//a[0] = 5;
	//for (int i = 1; i <= size; i++) {
	//	a[i] = size * i;
	//}
	//

	//calls functions
	create_array(a, size, intval);
	print_array(a, size);

	delete[] a;
	a = NULL;
	cout << "done!" << endl;
	return 0;
}
//creates an array.
//inputs: p,size and initval.
//makes an array, and puts values of initval into it with the given size.
void create_array(int * &p, int size, int initval) {
	for (int i = 0; i < size; i++) {
		*&p[i] = initval;
	}

}
//prints arrays.
//inputs: int array, and int for size.
void print_array(int a[], int size) {
	for (int i = 0; i < size; i++) {
		cout << "The values of the array are: " << a[i] << " " << endl;
	}
}