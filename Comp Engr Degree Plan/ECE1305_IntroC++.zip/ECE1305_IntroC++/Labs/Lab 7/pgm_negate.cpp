/*

Worked with: NAMES
Class: ECE 1305-04
4/14/2017

LAB 07, part 3.7

Description:
Takes files, reads in data, and find their avg, min and max, and prints that data. Uses pointers and
dynamic arrays.
*/

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

string get_filename();
void readPGM(string fname, int &nc, int &nr, int &mv, int * &pix);
void negatePGM(int nc, int nr, int mv, int *pix);
void writePGM(string fname, int nc, int nr, int mv, int *pix);

//.......................................

int main()
{
	int ncols = 0, nrows = 0, maxval = 255;
	int *pix = NULL;        // instead of static int pix[1024*1024];
	string filename = get_filename();

	readPGM(filename, ncols, nrows, maxval, pix);
	negatePGM(ncols, nrows, maxval, pix);
	writePGM("neg_" + filename, ncols, nrows, maxval, pix);

	// add code to delete the pixel array here!
	delete[]pix;
	pix = NULL;
}

//.......................................

// get the filename of an existing file.
string get_filename()
{
	
	bool ok = false;
	string fn = "";
	do
	{
		if (fn.size() == 0) cout << "filename? ";
		else cout << "can't open " << fn << ". re-enter filename: ";
		cin >> fn;
		ifstream ifs(fn);       // make sure we can open the file.
		if (ifs) ok = true;
	} while (!ok);
	
	return fn;
	
}

//............................write these two functions:

//readPGM:  opens file, reads header, allocates pixel array, reads in pixels.
//note that nc, nr, mv and pix are all passed by reference.
void readPGM(string fname, int &nc, int &nr, int &mv, int * &pix){
	ifstream ifs(fname);
		ifs >> nc >> nr >> mv;
	for (int r = 0; r < nr; r++) {
		for (int c = 0; c < nc; c++) {
			int ix = r*nc + c;
			ifs >> *&pix[ix];
		}
	}
	ifs.close();

	
}

//.......................................

//writePGM:  opens output file, outputs header line, outputs pixel array.
void writePGM(string fname, int nc, int nr, int mv, int *pix)
{
	
	ofstream ofs(fname);


	ofs << " " << nc << " " << nr << " " << mv << " ";

	for (int r = 0; r < nr; r++) {
		for (int c = 0; c < nc; c++) {
			int ix = r*nc + c;
			ofs << &pix[ix] << " ";
		}
		cout << endl;
	}
}
//.......................................

//negatePGM:  note that pix is passed by value.  but since it is a pointer,
//we can still modify the pixel array by indexing it.  why?
void negatePGM(int nc, int nr, int maxval, int *pix)
{
	for (int r = 0; r<nr; r++)
		for (int c = 0; c<nc; c++)
			pix[r*nc + c] = maxval - pix[r*nc + c];
}