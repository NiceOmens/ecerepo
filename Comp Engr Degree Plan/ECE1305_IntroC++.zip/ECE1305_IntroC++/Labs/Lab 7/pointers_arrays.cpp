/*

Worked with: NAMES
Class: ECE 1305-04
4/10/2017

LAB 07, part 2.4

Description:
Shows the use of pointers when working with various arrays of chars and ints.

*/


#include <iostream>
using namespace std;

int main()
{
	int i = 5, j = 51, k = 62;
	int data[5] = { 10, 20, 30, 40, 50 };
	char my_cstring[8] = "the fox";

	int *p = NULL;
	char *pc = NULL;

	p = data;

	//for data array
	cout << "The elements in array data are: ";
	for (int i = 0; i < 5; i++) {
		cout << data[i] << " ";
	}
	cout << endl;

	cout << "Outputing values in pointer c that is assigned to array data.. ";
	for (int i = 0; i < 5; i++) {
		cout << p[i] << " ";
	}
	cout << endl;

	cout << "Outputting the values of data increments pointer p.. ";
	for (i = 0; i < 5; i++) {
		cout << data[i] << " ";

		p++;
	}
	cout << endl;

	p = data;

	cout << "Outputting the values of data with adding i, all dereferenced.. ";
	for (int i = 0; i < 5; i++) {
		cout << *(p + i) << " ";
	}
	cout << endl;
	//*p+1 only dereferences the first element of p, which is 10. So all this
	//does is add i to 10, 5 times. *(p+1) does what we execpt, dereferencing each element
	//of the array.


	cout << "done" << endl;
#ifdef WIN32
	system("pause");
#endif
	return 0;
}
