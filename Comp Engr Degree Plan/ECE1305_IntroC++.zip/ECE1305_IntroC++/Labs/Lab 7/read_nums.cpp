/*

Worked with: NAMES
Class: ECE 1305-04
4/10/2017

LAB 07, part 3.6 PART A-B

Description:
Takes files, reads in data, and find their avg, min and max, and prints that data. Uses pointers and 
dynamic arrays.
*/

#include <iostream>
using namespace std;
#include<iomanip>
#include<string>
#include <fstream>

//prototypes for functions
bool read_data(string *q, double &size, double *&p);
int average(const double *p,const double &size,double &average);
void minmax(const double *p,const double &size, double &min,double &max);
int main() {
	//intil. vars
	string filenames[2];
	double size = 0;
	double avg = 0;
	double *a = NULL;
	double max = 0;
	double min = 0;

	//askins for file names
	cout << "Please enter first file name: ";
	cin >> filenames[0];
	cout << "Please enter second file name: ";
	cin >> filenames[1];

	//putting them in a pointer for ease of use
	string *q = NULL;
	q = filenames;
	//checks to make sure we opened files
	if (!(read_data(&q[0], size, a))) {
		cout << "Error! Coult not read data!" << endl;
		return 1;
	}
	//same
	if (!(read_data(&q[1], size, a))) {
		cout << "Error! Coult not read data!" << endl;
		return 1;
	}
	//calls functions
	cout << "Data for first file: " << endl;
	read_data(&q[0], size, a);
	average(a, size, avg);
	minmax(a, size, min, max);
	cout << endl;

	cout << "Data for second file: " << endl;
	read_data(&q[1], size, a);
	average(a, size, avg);
	minmax(a, size, min, max);

	//deletes array.
	delete[]a;
	a = NULL;
	cout << "done!" << endl;
	return 0;
}

//reads in data.
//uses *q for names(input)
//and size and *p for output of size and array.
bool read_data(string *q, double &size, double *&p) {
	string line;
	ifstream in(*q);
	if (!in) {
		cout << "Error! Could not open file!" << endl;
		return false;
	}
	else
	in >> size;
	p = new double[size];
	int temp = 0;

	for (int i = 0; i < size; i++) {
		in >> p[i];
	}
	in.close();
	return true;
}


//finds average of p. All are intputs but avg.
int average(const double *p, const double &size,double &avg){


	avg = 0;
	cout << "The size is: " << size << endl;
	double sum = 0;
	for (int i = 0; i < size; i++) {
		sum += p[i];
	}
	avg = sum / size;
	cout << "The average is " << avg << endl;
	return avg;
}

//finds min and max of p using algo we have used many times.
//min and max are "outputs" p and size are inputs.
void minmax(const double *p, const double &size, double &min, double &max) {
	double big = p[0];
	for (int i = 1; i < size; i++) {
		if (p[i] > big) {
			big = p[i];
		}
	}
	max = big;

	double smallest = p[0];
	for (int i = 1; i < size; i++){
		if (p[i] < smallest) {
			smallest = p[i];
	
		}
	}
	cout << "The min value in the array is: " << smallest << endl;
	cout << "The max value in array is: " << max << endl;
}