/*

Worked with: No one
Course:     ECE 1305-004, spring 2017
Date:		4/18/2017
Assignment: Lab 08 part 1.1

Description:
Writes array a into a file, then reads that file into array b and
outputs that array.

*/


#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

int main() {

	//initiates vars
	int a[11] = { 543516756, 1667855729, 1919033451, 544110447, 544763750, 1886221674, 1986994291, 1948283493, 1814062440, 544832097, 778530660 };
	int b[11] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	string fname = "binary.dat";
	ofstream ofs;
	ofs.open(fname);
	ifstream ifs;

	//makes sure file was made/can be opened.
	if (!ofs) {
		cout << "Error! Could not open file." << endl;
		return 1;
	}

	//puts array a into fname.
	int q = 0;
	while (q < 1) {
		for (int c = 0; c < 11; c++) {

			ofs << a[c] << " ";
		}
		q++;
	}
	ofs.close();
	cout << "done writing array a..." << endl;
	
	cout << "Starting write of array b.." << endl; 
	ifs.open(fname);

	if (!ifs) {
		cout << "Error! file " << fname << " " << "could not be found!" << endl;
		return 2;
	}
	q = 0;
	//puts values of file into array b.
	while (q < 1) {
		for (int c = 0; c < 11; c++) {

			ifs >> b[c];
		}

		q++;
}
	//outputs b.
	cout << "The value of array b are: " << endl;
	for (int i = 0; i < 11; i++) {
		cout << b[i] << endl;
	}
	ifs.close();
	return 0;
}