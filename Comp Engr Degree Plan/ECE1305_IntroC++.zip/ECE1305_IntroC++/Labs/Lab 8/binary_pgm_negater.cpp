/*
Takes a binary P5 image, takes data from it, writes it to a copy and makes a
photonegative version. 

*/


#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

int main() {
	
	//variables
	int ncols, nrows, maxval;
	string type, fname;
	string outname, neg;
		cout << "Please enter file name: " << endl;
		cin >> fname;
		outname = fname + "copy.pgm";
		neg = fname + "neg.pgm";
	//main file name as well as copy and negative names.

	//reads file.
	ifstream ifs(fname,ios::binary);
	char junk;
	//ofstream ofs(fname, ios::binary);
	if (!ifs) {
		cout << "Error! Could not open " << fname << endl;
		return 1;
	}
	//reads file header
	ifs >> type >> ncols >> nrows >> maxval;
	ifs.read(&junk, 1);
	int size = ncols*nrows;
	 char* buffer = new char[size];
	 
	ifs.read(buffer, size);
	//makes sure its open
	if(!ifs) {
		cout << "File not read successfully!" << endl;
		return 1;
	}

	int* array = new int[size];
	//gets values and puts them in an int array.
	for (int r = 0; r < nrows; r++) {
		for (int c = 0; c < ncols; c++) {
			int ix = r*ncols + c;
			array[ix] = buffer[ix];
			
		}
	}

	//This outputs the copy.
	cout << "Creating copy photo.." << endl;
	ofstream ofs1(outname,ios::binary);
	ofs1 << type << " " << ncols << " " << nrows << " " << maxval << " ";
	ofs1.write(buffer, size);
	cout << "done!" << endl;

	//this outputs the photonegative version.
	char *negative = NULL;
	negative = new char[size];
	cout << "Creating photo negative.." << endl;

	//makes a photonegative.
	for (int i = 0; i < size; i++)
	{
		negative[i] = maxval - array[i];
	}
	ofstream ofs2(neg, ios::binary);
	ofs2 << type << " " << ncols << " " << nrows << " " << maxval << " ";
	ofs2.write(negative, size);
	cout << "done!" << endl;


	cout << "All done!" << endl;
	delete[]buffer;
	delete[]negative;
	return 0;
}