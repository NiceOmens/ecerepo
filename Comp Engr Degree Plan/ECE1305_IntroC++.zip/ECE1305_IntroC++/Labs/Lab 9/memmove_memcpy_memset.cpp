/*

Worked with: No one
Course:     ECE 1305-004, spring 2017
Date:		4/18/2017
Assignment: Lab 09 part 3

Description:
Uses memset,memcpy and memmove to dynamically allocate and more data 
around.

*/


#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

int main() {
	char *thing1 = NULL;
	char *thing2 = NULL;
	thing1 = reinterpret_cast<char *>(malloc(128));
	thing2 = reinterpret_cast<char *>(malloc(128));
	memset(thing1,'*',128);
	thing1[20] = '\0';
	for (int i = 22; i < 26; i++) {
		memset(thing1 + i, '%', 1);
	}
	cout << "Array thing1 contains: " << endl;
	cout << thing1 << endl;
	memset((thing1+22), '\0', 1);
	cout << (thing1+22) << endl;

	cout << "values of thing1 now: " << endl;
	for (int i = 0; i < 50; i++) {
		cout << thing1[i] << endl;
	}

	memset(thing2, '$', 128);
	memcpy(reinterpret_cast<char *>(&thing2[7]), reinterpret_cast<char *>(&thing1[0]),sizeof(double));
	memcpy(reinterpret_cast<char *>(&thing2[8]), reinterpret_cast<char *>(&thing1[1]), sizeof(double));
	memcpy(reinterpret_cast<char *>(&thing2[9]), reinterpret_cast<char *>(&thing1[2]), sizeof(double));
	memcpy(reinterpret_cast<char *>(&thing2[10]), reinterpret_cast<char *>(&thing1[3]), sizeof(double));
	memcpy(reinterpret_cast<char *>(&thing2[11]), reinterpret_cast<char *>(&thing1[4]), sizeof(double));
	memcpy(reinterpret_cast<char *>(&thing2[12]), reinterpret_cast<char *>(&thing1[5]), sizeof(double));
	
	cout << "values of thing1 now: " << endl;
	for (int i = 0; i < 50; i++) {
		cout << thing2[i] << endl;
	}
	for (int i = 15; i < 26; i++) {
		int j = i - 8;
		memmove(reinterpret_cast<char *>(&thing1[j]), reinterpret_cast<char *>(&thing1[i]), sizeof(double));
	}

	cout << "The C string is: " << endl;
	cout << thing1 << endl;

	cout << "All 50 numeric values are: " << endl;
	for (int i = 0; i < 50; i++) {
	cout << thing1[i] << endl;
	}


	for (int i = 0; i < 20; i++) {
		int j = i - 10;
		memmove(reinterpret_cast<char *>(&thing2[j]), reinterpret_cast<char *>(&thing2[i]), sizeof(double));

	}
	cout << "The values of thing2 using memmove are now: " << endl;
	for (int i = 0; i < 50; i++) {
		cout << thing2[i] << endl;
	}
	for (int i = 0; i < 20; i++) {
		int j = i - 10;
		memcpy(reinterpret_cast<char *>(&thing2[j]), reinterpret_cast<char *>(&thing2[i]), sizeof(double));
	}
	cout << "The values of thing2 using memcpy are now: " << endl;
	for (int i = 0; i < 50; i++) {
		cout << thing2[i] << endl;
	}
	//Yes I got what I expected.

	return 0;
}