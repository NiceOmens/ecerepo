/*

Worked with: No one
Course:     ECE 1305-004, spring 2017
Date:		4/18/2017
Assignment: Lab 08 part 2

Description:
Demonstrates the uses of malloc and calloc, as well as free.

*/


#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

int main() {
	int *array = NULL;
	array = reinterpret_cast<int *>(calloc(5,sizeof(int)));
	array[2] = 259;
	
	cout << "The values of the calloc array are: " << endl;
	for (int i = 0; i < 5; i++) {
		cout << array[i] << endl;
	}

	double *mal = NULL;
	mal = reinterpret_cast<double *> (malloc(sizeof(double)*10));
	mal[2] = 259.0;
	mal[3] = 259.875;

	cout << "The values of the malloc array are: " << endl;
	for (int i = 0; i < 10; i++) {
		cout << mal[i] << endl;
	}





	free(mal);
	free(array);
	return 0;
}