
//Worked with: No one
//Course:     ECE 1305-004, spring 2017
//Assignment: Lab 02, part 1a/b, "add_numbers"
//
//Description: 
//A tool that asks the user how many numbers the user would like to add up, then creates a loop asking the user for a number that many times.

#include <iostream>
using namespace std;

int main() {
	// setting variables
	float counter;
	float number;
	float sum = 0;
	float average;
	float loops;
	//asks user how many loops they want to run.
	cout << "How many numbers would you like to enter? ";
	cin >> loops; // sets that number to 'loops'

	//for loop which sets the counter to 0, and increments the counter until you have reached the 'loops' value set by user.
	for (counter = 0; counter < loops; counter++) {
		cout << "Please enter your number: ";
		cin >> number;
		//sum is the numbers added up.
		sum += number;
		
	}
	//average calculations
	average = sum / 6;

	//outputs the sum and average.
	cout << "The sum of your 6 numbers is " << sum << endl;
	cout << "The average of your 6 numbers is " << average << endl;

	return 0;

}