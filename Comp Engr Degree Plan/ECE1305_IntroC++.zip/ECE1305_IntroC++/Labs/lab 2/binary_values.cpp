
//Worked with: No one
//Course:     ECE 1305-004, spring 2017
//Assignment: Lab 02, challenge
//
//Description: 
//Takes a positive integer from the user and outputs the binary representation of it.

using namespace std;
#include <iostream>
#include <bitset>

int main() {

	int c;
	
	cout << "Please enter a positive integer: ";
	cin >> c;

	string binary = bitset<8>(c).to_string();
	cout << binary << endl;

	return 0;
}