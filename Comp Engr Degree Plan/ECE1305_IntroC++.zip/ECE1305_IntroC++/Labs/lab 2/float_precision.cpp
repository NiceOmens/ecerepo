
//Worked with: No one
//Course:     ECE 1305-004, spring 2017
//Assignment: Lab 02, part 3, float precision
//
//Description: 
//Looking at setprecision, floats, and doubles with PI to see how accurate and how many digits each would represent.
//Author: Ian Scott-Fleming

#define _USE_MATH_DEFINES
#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main(void)
{
	float f = 1.234;
    double d = 1.2345; 
	long double ld = 1.23456;

	float a = M_PI;
	double b = M_PI;


	cout << "\n\there is PI to many decimal places:  "<<endl;
	cout << "PI:              3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679"<<endl;
    cout << "f set to 1.234, d to 1.2345, and ld to 1.23456"<<endl;
	cout << "float:           "<<setprecision(10)  << f  << endl;
	cout << "double:          "<<setprecision(20)  << d  << endl;
	cout << "long double:     "<<setprecision(30)  << ld << endl;
	cout << "PI/2:            "<<setprecision(30)  << M_PI/2 << endl;
	cout << "sqrt(PI):		  "<<setprecision(30)  << sqrt(M_PI) << endl;
	cout << "PI from M_PI:    " <<setprecision(30) << M_PI << endl;


	cout << "\n\n\tHere's an interesting way to get PI to double-precision:" << endl;
	cout << "PI:              3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679"<<endl;
	cout << "arc-cosine(-1):  " << setprecision(20)  << acos(-1.0) << endl;
	cout << "M_PI:            " << setprecision(20)  << M_PI << endl;
    
    // Declare a variable of type float, and another of type double, and assign the value of PI (with at least 20 digits) to them, and then output Your values for PI.
    // How many digits do you get before the result diverges from the (approximately correct) value given above?

	//float gives you 7 and double gives you 14 correct digits.
	cout << "PI float: " << setprecision(20) << a <<  endl;
	cout << "PI double: " << setprecision(20) << b << endl;
    // You can use the following:
long double very_long_pi = 3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679L;   //adding L to a floating pt constant makes it a long-double.
																																	  // output .1, .2, ... 1.0 to see how well
																																	  // C++ can represent these values.
cout << fixed;      // use fixed precision notation
for (int i = 0; i <= 10; i++)
{
	f = i / 10.0f;         // 10.0f is 10 as a float constant
	d = i / 10.0;          // 10.0  is 10 as a double constant
	ld = i / 10.0L;        // 10.0L is 10 as a long double constant;
	cout << endl << i << endl;
	cout << "\tfloat:       " << setprecision(5) << f << " " <<
		setprecision(10) << f << " " <<
		setprecision(20) << f << endl;
	cout << "\tdouble:      " << setprecision(5) << d << " " <<
		setprecision(10) << d << " " <<
		setprecision(20) << d << endl;
	cout << "\tlong double: " << setprecision(5) << ld << " " <<
		setprecision(10) << ld << " " <<
		setprecision(20) << ld << endl;
}
	return 0;
}



