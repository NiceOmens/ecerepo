
//Worked with: No one
//Course:     ECE 1305-004, spring 2017
//Assignment: Lab 02, part 3, int_ranges
//
//Description: 
//Outputs 200 values, starting from below 100 of the maximum, for int, unsigned short and short. 




#include <iostream>
#include <iomanip>

using namespace std;

int main(void)
{
	// all values assigned are 100 off of max
	unsigned short us = 65435;
	signed short s = 32667;
	int INT = 2147483547;
	
	//Loop structure: Starts counter, outputs values from a while loops which goes for 200 runs. Inside the loop respected variables(counter and value) is 
	//incremented by 1 for each loop run. Outputs 16 values per line.
	int q = 1; // counter
	cout << endl << "Int: values from 100 below the max value: " << endl;
	while (q <= 200)					// loop for 200 times
	{
		cout << static_cast<int>(INT) << " ";
		if (q % 8 == 0) //only displaying 8 per line here due to the massive size of the numbers.
		{
			cout << endl;
		}
		INT = INT + 1; // increments INT
		q++;		// increments counter
	}
	
	int n = 1;	// counter
	cout << endl << "unsigned short: values from 100 below the max value: " << endl;
	while (n <= 200)					// loop using a while loop
	{
		cout << setw(4) << static_cast<unsigned short>(us) << " ";
		if (n % 16 == 0)				// output a newline every 200
			cout << endl;
		us = us + 1;						
		n++;
	}


	int m = 1; //counter
	cout << endl << "signed short: values from 100 below the max value:  " << endl;
	while (m <= 200)
	{
			cout << setw(4) << static_cast<short>(s) << " ";
			if (m % 16 == 0)			// 16 per line
				cout << endl;
			s = s + 1; //incrementing the counter and the value of s.
			m++;
							
		}
		cout << "\nFinished!" << endl;
	
	return 0;

}




