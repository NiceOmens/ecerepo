/*

Worked with: No one
Class: ECE 1305-04

Quadratic Challenge

Description:
Takes in a,b and c and outputs how many soultions
and what those solutions are.

The program also loops until the user enters 0 0 0 
for a,b and c.
*/

#include <iostream>
using namespace std;
int main() {

	//declare variables
	float a = 1;
	float b = 1;
	float c = 1;
	float d;
	float x1;
	float x2;
	

	//Help user understand input req.
	cout << "Quadratic in form of ax^2 + bx + c = 0" << endl;

	//loops until a, b and c are 0
	while ((a && b && c) > 0) {
		cout << "Please enter your numbers for a, b and c: ";
		cin >> a >> b >> c;
		
		// if they are zero, exit.
		if ((a && b && c) == 0)
		{
			exit(0);
		}
		//inside of square root.
		d = (pow(b,2)) - (4 * a*c);

		//if d is negative, exit. AKA no real roots, but imaginary ones.
		if (d < 0) {
			cout << "No real soultion!" << endl;
			exit(0);
		}
		else {
			//math for roots
			x1 = (-b + sqrt(d)) / (2 * a);
			x2 = (-b - sqrt(d)) / (2 * a);
		}
		//if they are equal no point in printing 2 of the same numbers, only 1 root!
		if (x1 == x2) {
			cout << "The root to your equation is: " << x1 << endl;
		}
		//This means there are 2 roots
		else {
			cout << "The roots for your equation are: " << x1 << " and " << x2 << endl;
			
		}
		cout << "Please enter 0 0 0 to exit. . ." << endl;
	}
	return 0;


}





