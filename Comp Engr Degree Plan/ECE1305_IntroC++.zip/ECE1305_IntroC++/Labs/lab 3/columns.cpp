/*

Worked with: No one
Class: ECE 1305-04
2/14/2017

LAB 03, part 2

Description:
Outputs columns and rows of a number specified by the user, in a given number of rows specified by the user.

*/


#include <iostream>
using namespace std;
int main(int)
{
	int rows;
	int numr;
	int col;
	int num = 0;

	cout << "How many number to output? ";
	cin >> numr;

	cout << "How many rows? ";
	cin >> rows;

	//checks to see if rows are divisible by the number given by user
	if ((numr%rows) == 0) {
		col = numr / rows;
	}
	else {
		col = (numr / rows) + 1;
		
	}


	for (int r = 0; r < rows; r++)		// output rows specified by user
	{
		for (int c = 0; c < col; c++)	// output # of columns that have enough room for numbers given by user
		{
			
				num = c * rows + r + 1;		// outputting c value * row value + current row + 1

				//If the num is greater than that of the users specificed value, end the loop.
				if (num >= numr + 1) {
					break;
				}
				else
				cout << "\t" << num;
		
			
		}
		cout << endl;	// put a newline at the end of each row


		
	}
	return 0;
}