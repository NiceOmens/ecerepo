/*

Worked with: No one
Class: ECE 1305-04
2/14/17

LAB 03, part 4

Description:
Makes a pgm of a right triangle side with different colors,
with a name specificed by user.



*/



#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

int main(void) {

	//variables
	int row = 20;
	int col = 30;
	int maxval = 255;
	int backcolor = 50;
	int shading = maxval / row;

	ofstream image;
	string imageName;
	string fNameIn;





		// Prompts user for the PGM filename
		cout << "What would you like to name your PGM File? ";
		cin >> fNameIn;

		imageName = fNameIn + ".pgm";
		// Creates pgm
		image.open(imageName.c_str());

		//Header for file
		image << "P2" << col << " " << row << " " << maxval << endl;

		for (int i = 0; i < row; i++) //for rows
		{
			for (int j = 0; j < col; j++) //for columns
			{

				if (j == 0) {

					//Puts 50 for the background color.
					image << backcolor << " ";
					continue;

				}

				//Checks to make sure not on last row
				if (j < i + 1 && i != row - 1) {

					image << i * shading << " ";
				}
				else {
					// Prints the last row a solid color
					image << backcolor << " ";

				}
			}

			image << endl;

		}

		// Lets the user know that their file has been created
		cout << "done!" << endl;

		image.close();
	
	}










