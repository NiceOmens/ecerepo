/*

Worked with: No one
Class: ECE 1305-04
2/14/2017

LAB 03, part 1

Description:
Prompts user for 5 2-D cordinates to write to a text file.

*/


#include <iostream>
#include <iomanip>
#include <cctype>
#include <fstream>
using namespace std;

int main() {

	float num1 = 0, num2 = 0;
	int q = 0;
	ofstream myfile;
	myfile.open("points.txt"); //creates text file

	while (q < 5) {
		cout << "Please enter 2 numbers: ";
		cin >> num1 >> num2;
		myfile << num1 <<  " " << num2;
		myfile << endl;

		q++;


	}
	cout << "done!";
	
	myfile.close();
	return 0;
}

	





	
