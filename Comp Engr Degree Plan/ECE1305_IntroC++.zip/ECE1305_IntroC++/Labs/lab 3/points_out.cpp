/*

Worked with: No one
Class: ECE 1305-04
2/14/17

LAB 03, part 1

Description:
Reads points from points.txt, prints them in console and calculates their distance from origin
in a circle with a radius of 20, and whether they are in that radius.

Please note points.txt must be in directory with .cpp file to work.

*/





#include <iostream>
#include <iomanip>
#include <cctype>
#include <fstream>
#include<string>
using namespace std;


int main() {



	int x1, x2, x3, x4, x5;
	int y1,y2,y3,y4,y5;
	int c1, c2, c3, c4, c5;
	int d1, d2, d3, d4, d5;

	ifstream in("points.txt");


	//stores files values into respected int's. Not sure how we were suppose to do this without arrays cleanly..
	while (in >> x1 >> y1 >> x2 >> y2 >> x3 >> y3 >> x4 >> y4 >> x5 >> y5) {
		

		//calculates whether the values are inside r = 20.
		c1 = pow(pow(x1, 2) + pow(y1, 2), .5);
		c2 = pow(pow(x2, 2) + pow(y2, 2), .5);
		c3 = pow(pow(x3, 2) + pow(y3, 2), .5);
		c4 = pow(pow(x4, 2) + pow(y4, 2), .5);
		c5 = pow(pow(x5, 2) + pow(y5, 2), .5);




		//Bunch of logic checking if the distance from origin is further than 20, if it is then
		//you get that info with the distance, does this for all 5 sets of points
		if (c1 > 20 || c1 < -20) {
			cout << "Cordinate pair " << x1 << "," << y1
				<< " is not in the radius of the circle." << endl;
			cout << "Distance from origin is " << c1 << endl;
		}
		else {
			cout << "Cordinate pair " << x1 << "," << y1
				<< " is in the radius of the circle." << endl;
			cout << "Distance from origin is " << c1 << endl;

		}
		if (c2 > 20 || c2 < -20) {
			cout << "Cordinate pair " << x2 << "," << y2
				<< " is not in the radius of the circle" << endl;
			cout << "Distance from origin is " << c2 << endl;
		
		}
		else {
			cout << "Cordinate pair " << x2 << "," << y2
				<< " is in the radius of the circle." << endl;
			cout << "Distance from origin is " << c2 << endl;

		}
		if (c3 > 20 || c3 < -20) {
			cout << "Cordinate pair " << x3 << "," << y3
				<< " is not in the radius of the circle." << endl;
			cout << "Distance from origin is " << c3 << endl;
		}
		else {
			cout << "Cordinate pair " << x3 << "," << y3
				<< " is in the radius of the circle." << endl;
			cout << "Distance from origin is " << c3 << endl;

		}		
		if (c4 > 20 || c4 < -20) {
			cout << "Cordinate pair " << x4 << "," << y4
				<< " is not in the radius of the circle." << endl;
			cout << "Distance from origin is " << c4 << endl;
		}
		else {
			cout << "Cordinate pair " << x4 << "," << y4
				<< " is in the radius of the circle." << endl;
			cout << "Distance from origin is " << c4 << endl;

		}
		if (c5 > 20 || c5 < -20) {
			cout << "Cordinate pair " << x5 << "," << y5
				<< " is not in the radius of the circle." << endl;
			cout << "Distance from origin is " << c5 << endl;
		}
		else {
			cout << "Cordinate pair " << x5 << "," << y5
				<< " is in the radius of the circle." << endl;
			cout << "Distance from origin is " << c5 << endl;

		}



	}
	//closes txt file
	in.close();
	return 0;
}






