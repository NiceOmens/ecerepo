/*

Worked with: No one
Class: ECE 1305-04
2/21/2017

LAB 04, part 2

Description:
Prompts user for a day of the year, and returns the month and day
that numbers falls on.

*/


#include <iostream>
#include <iomanip>
#include <cctype>
#include <fstream>
#include <string>
using namespace std;

int main(void) {

	string month[12] = { "January" , "February", "March","April","May","June","July","August","September","October","Novemeber","December"};
	string days[12] = { "31","28","31","30","31","30","31","31","30","31","30","31" };
	int day = 0;
	
	//asks user for input
	while (day > -1) {
		cout << "Enter a day-of-year (or -1 to quit) : " << endl;
		cin >> day;
		if (day < 0) {
			exit(1);

		}
		//Jan
		if (day <= 31) {
			cout << "Day " << day << "is " << 31 - day << " " << month[0] << endl;
		}
		//feb
		else if (day > 31 && day < 59) {
			cout << "Day " << day << " is " << day -31 << " " << month[1] << endl;
		}
		//mar
		else if (day > 59 && day < 90) {
			cout << "Day " << day << " is " << day - 59 << " " << month[2] << endl;
		}
		//apr
		else if (day > 90 && day < 120) {

			cout << "Day " << day << " is " << day - 90 << " " << month[3] << endl;
		}
		//may
		else if (day > 120 && day < 151) {

			cout << "Day " << day << " is " << day - 120 << " " << month[4] << endl;
		}
		//june
		else if (day > 151 && day < 181) {

			cout << "Day " << day << " is " << day -151 << " " << month[5] << endl;
		}
		//july
		else if (day > 181 && day < 212) {

			cout << "Day " << day << " is " << day -181 << " " << month[6] << endl;
		}
		//aug
		else if (day > 212 && day < 243) {

			cout << "Day " << day << " is " << day- 212 << " " << month[7] << endl;
		}
		//sep
		else if (day > 243 && day < 273) {

			cout << "Day " << day << " is " << day -243<< " " << month[8] << endl;
		}
		//oct
		else if (day > 273 && day < 304) {

			cout << "Day " << day << " is " << day - 273 << " " << month[9] << endl;
		}
		//nov
		else if (day > 304 && day < 334) {

			cout << "Day " << day << " is " << day  - 304<< " " << month[10] << endl;
		}
		//dec
		else if (day > 334) {

			cout << "Day " << day << " is " << day - 334 << " " << month[11] << endl;
		}
		else {
			cout << "That wasn't a valid entry!" << endl;
		}
	}

	return 0;
}