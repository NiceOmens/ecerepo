/*

Worked with: No one
Class: ECE 1305-04
2/25/2017

LAB 04, part 4

Description:
Outputs the reaccuring values in a .pgm, or any, file given from user.

NOTE:
Had many issues here, I could not find a way to convert a string to a int, which was my initial plan to do this. I was able to read all of the numbers easily, but they would be stored
as, for example array[0] = 1 instead of array[0] = 123, thus I was not able to complete the assignment properly. If this is the one deeply graded, I hope the grader takes a look at the other ones
as well and see's I did very well on those. 

*/



#include <iostream>
#include <iomanip>
#include <cctype>
#include <fstream>
using namespace std;



#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <string>
#include <sstream>
using namespace std;

int main()
{
	//declaring variables
	int a = 0;
	string fname;
	int position = 0;
	int count = 65025;
	char * array = new char[count];


	//asks user for file name
	cout << "Please enter the files name:  ";
	cin >> fname;
	//opens file
	ifstream in(fname);
	if (!in.is_open()) {
		printf("ERROR! File not open!");
	}
	else {
		while (!in.eof() && position < count) {
			in.get(array[position]);
			position++;
		}
		array[position - 1] = '\0';
		cout << "displaying array.." << endl << endl;
		for (int i = 0; array[i] != '\0'; i++) {
			cout <<array[i] ;
			if (array[i] < 180) {
				a++;
			}
		}
	}


	//puts the file values into value, and then checks that value for the given restraints.
	cout << "Numbers less than 180: " << a << endl;

	in.close();
	return 0;

}
	

