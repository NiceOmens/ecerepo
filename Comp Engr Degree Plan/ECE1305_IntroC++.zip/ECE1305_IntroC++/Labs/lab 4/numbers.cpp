/*

Worked with: No one
Class: ECE 1305-04
2/21/2017

LAB 04, part 1

Description:
Prompts user for 6 int values, then calculates the sum, avg, 
and displays the elements forwards and backwards;

*/


#include <iostream>
#include <iomanip>
#include <cctype>
#include <fstream>
using namespace std;

int main(void) {
	 
	int num[6];
	int sum = 0;
	float avg = 0;

	//asks user for inputs
	for (int i = 0; i < 6 ; i++) {
		cout << "Please enter a number: ";
		cin >> num[i];
	}
	cout << endl;

	//outputs array num
	cout << "Your data was: ";
	for (int i = 0; i <6; i++) {

		cout << num[i] << " ";
	}
	cout << endl;

	//sum
	cout << "The sum and average are: ";
	for (int i = 0; i <6 ; i++) {
		sum += num[i];
		avg = sum / 6;
	}
	cout << sum << " " << avg << endl;
	
	//forwards
	cout << "Forwards: ";
	for (int i = 0; i < 6; i++) {

		cout << num[i] << " ";
	}
	cout << endl;

	//backwards
	cout << "Backwards: ";
	for (int i = 5; i >= 0; i--) {
		cout << num[i] << " ";
	}
	cout << endl;

	return 0;
}