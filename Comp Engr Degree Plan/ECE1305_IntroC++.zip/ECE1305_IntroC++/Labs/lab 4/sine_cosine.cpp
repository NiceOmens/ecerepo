/*

Worked with: No one
Class: ECE 1305-04
2/21/2017

LAB 04, part 3

Description:
Outputs the values of PI,sin,cos and .4cos+.8sin of PI from -3.1 to 3.1.

*/

#define _USE_MATH_DEFINES
#include <cmath>
#include <iostream>
#include <iomanip>
#include <cctype>
#include <fstream>
using namespace std;

//M_PI as PI for readability
const double PI = M_PI;

int main() {

	double PQ = 3.1;
	double PE = -3.1;
	double tenth = .1;


	//text file
	ofstream data;
	data.open("sines.txt");

	//arrays
	float x[65];
	//cos of x
	float y[65];
	//sin of x
	float z[65];
	//.4cosx+.8sinx
	float w[65];


	//puts the values in the respected arrays
	int i = 1;
	while(i < 64){
		for (double j = PE; j < 3.2;j+=.10 ) {
			x[i] = j;
			y[i] = cos(j);
			z[i] = sin(j);
			w[i] = .4*cos(j) + .8*sin(j);
				i++;
			}
	}
	//outputs the values to data.txt
	int k = 1;
	while(k < 64) {

		data << k << " " << x[k] << " " << y[k] << " " << z[k] << " " << w[k] << endl;
		k++;
	}
	//lets user know its done
	cout << "done!" << endl;




	//closes txt file
	data.close();
	return 0;
}