/*

Worked with: No one
Class: ECE 1305-04
3/08/2017

LAB 05, part 2

Description:
Demonstrates that the derivative of the sine function is the cosine
function.


*/


#define _USE_MATH_DEFINES
#include <iostream>
#include <iomanip>
#include <cmath>        
#include <algorithm>    
#include <cstdlib>    
using namespace std;

int main() {
	//vars and arrays
	double x[100];
	double sines[100];
	double cosines[100];
	double slopes[100];
	double diffs[100];
	double maxdiff = abs(diffs[0]);
	double mindiff = abs(diffs[0]);
	double delta = 2.0*M_PI / 100.0;

	//puts values into arrays
	for (int i = 0; i < 100; i++){
		x[i] = i * delta;
		sines[i] = sin(x[i]);
		cosines[i] = cos(x[i]);
	}
	//calculates the slopes and diffs
	for (int i = 0; i < 100; i++) {
		if (i == 0) {
			slopes[i] = ((sines[99]) - (sines[99])) / (2 * delta);
		}
		if (i == 99) {
			slopes[i] = ((sines[0]) - (sines[0])) / (2 * delta);
		}

		slopes[i] = ((sines[i + 1]) - (sines[i - 1])) / (2 * delta);
		diffs[i] = abs(slopes[i] - cosines[i]);
		cout << scientific << setprecision(4);
		cout << setw(8) << diffs[i];
	}
	//finds max diff and min diff
	for (int i = 1; i < 99; i++) {
		maxdiff = max(maxdiff, abs(diffs[i]));
		mindiff = min(mindiff, abs(diffs[i]));
	}

	return 0;
}