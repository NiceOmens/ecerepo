/*

Worked with: No one
Class: ECE 1305-04
3/8/17

LAB 05, part 1

Description:
Makes a pgm of a right triangle side with different colors,
with a name specificed by user.



*/


using namespace std;
#include <iomanip>
#include <iostream>
#include <ctime>
#include <cstdlib>

int main() {
	int ran;
	int random_val[10];
	int myseed;

	//asks user for seed
	cout << "Please enter your seed: ";
	cin >> myseed;

	//checks if seed is negative, if so uses time.
	if (myseed < 0) {
		srand(time(0));
	}
	//if not uses users given seed.
	else {
		srand(myseed);
	}
	//puts 10 random values from 0 to 100 in an array.
	cout << "values in array: ";
	for (int i = 0; i < 10; i++) {
		random_val[i] = rand() % 100 + 1;
		
	}

	//checks values in array and outputs.
	for (int i = 0; i < 10; i++) {
		if (random_val[i] < 1) {
			cout << "Wind speed of " << random_val[i] << " is calm." << endl;
		}
		else if (random_val[i] >= 1 && random_val[i] <= 3) {
			cout << "Wind speed of " << random_val[i] << " is light air." << endl;
		}
		else if (random_val[i] >= 4 && random_val[i] <= 7) {
			cout << "Wind speed of " << random_val[i] << " is light breeze." << endl;
		}
		else if (random_val[i] >= 8 && random_val[i] <= 12) {
			cout << "Wind speed of " << random_val[i] << " is genetle breeze." << endl;
		}
		else if (random_val[i] >= 13 && random_val[i] <= 18) {
			cout << "Wind speed of " << random_val[i] << " is moderate breeze." << endl;
		}
		else if (random_val[i] >= 19 && random_val[i] <= 24) {
			cout << "Wind speed of " << random_val[i] << " is fresh breeze." << endl;
		}
		else if (random_val[i] >= 25 && random_val[i] <= 31) {
			cout << "Wind speed of " << random_val[i] << " is strong breeze." << endl;
		}
		else if (random_val[i] >= 32 && random_val[i] <= 38) {
			cout << "Wind speed of " << random_val[i] << " is high wind." << endl;
		}
		else if (random_val[i] >= 39 && random_val[i] <= 46) {
			cout << "Wind speed of " << random_val[i] << " is gale." << endl;
		}
		else if (random_val[i] >= 47 && random_val[i] <= 54) {
			cout << "Wind speed of " << random_val[i] << " is severe gale." << endl;
		}
		else if (random_val[i] >= 55 && random_val[i] <= 63) {
			cout << "Wind speed of " << random_val[i] << " is storm." << endl;
		}
		else if (random_val[i] >= 64 && random_val[i] <= 72) {
			cout << "Wind speed of " << random_val[i] << " is violent storm." << endl;
		}
		else if (random_val[i] >= 73) {
			cout << "Wind speed of " << random_val[i] << " is hurricane." << endl;
		}
	}
	return 0;
}