/*

Worked with: No one
Class: ECE 1305-04
3/08/2017

LAB 05, part 4

Description: Takes a sentence from the user and outputs it in 
its parts by words.



*/



#include <iostream>
#include<map>
#include<stack>
#include<vector>
#include<istream>
#include<string>
using namespace std;

int main()
{
	cout << "Please enter your sentence below: " << endl;
	string str;
	std::getline(cin,str);
	vector<string> sentence;

	int a = 1;
	int b = 1;
	int c = 0;



	while (b != -1)
	{
		b = str.find(" ", a);
		sentence.push_back(str.substr(c, b - c));
		a = b + 1;
		c = a;
	}
	int i = 0;

	while (i < sentence.size())
	{
		cout << sentence[i] << endl;
		i++;
	}
	return 0;
}