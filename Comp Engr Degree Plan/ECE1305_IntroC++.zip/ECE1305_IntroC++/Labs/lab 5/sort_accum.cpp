/*

Worked with: No one
Class: ECE 1305-04
3/08/2017

LAB 05, part 3

Description:
Generates 10 random numbers from 10 and 20, sorts them, prints those, 
and calculates sum and average, and uses accumulate to calculate an 
average as well.


*/


#define _USE_MATH_DEFINES
#include <iostream>
#include <iomanip>
#include <cmath>        
#include <algorithm>    
#include <cstdlib>  
#include <ctime>
#include <numeric> 
using namespace std;

int main() {

	srand(time(NULL));
	float random_val[10];
	float sumNorm = 0;
	float sumAcc = 0;
	float avg = 0;
	int size = 10;

	//puts 10 ran values into array
	for (int i = 0; i < size; i++) {
		int ran = (rand() %(11))+10;
		random_val[i] = ran;
	}

	cout << "The random values in the array are: " << endl;
	for (int i = 0; i < size; i++) {
		sort(random_val,random_val);
		cout << random_val[i] << endl;
	}
	//sum normal way
	for (int i = 0; i < size; i++) {
		sumNorm += random_val[i];
	}
	//average
	avg = sumNorm/size;

	//sum with accumulate
	for (int i = 0; i < 10; i++) {
	sumAcc = accumulate(random_val, random_val+10,0);
	}

	cout << "The sum calculated normally is: " << sumNorm << endl;
	cout << "The avgerage is: " << avg << endl;
	cout << "The sum calculated with accumulate is: " << sumAcc << endl;
	return 0;
}