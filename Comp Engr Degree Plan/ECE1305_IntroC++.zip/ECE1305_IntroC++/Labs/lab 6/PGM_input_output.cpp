/*

Worked with: No one
Class: ECE 1305-04
3/23/2017

LAB 06 challenge

Description:
Opens a PGM, reads the header and values in the file. Outputs the
header and pixels to console and saves them in a new .pgm file.

*/

#include <iomanip>
#include <iostream>
#include <fstream>
#include <string>

//If running a version of VisualStudio earlier than 2015, uncomment the following line:
//
//#pragma comment(linker, "/STACK:16777216")
//
// It increases the stack size to 16 MB.  Default stack size in earlier versions of VS is 1 MB, and the
// pixel array of 512x512 ints completely uses up the 1 MB stack.


using namespace std;

bool get_filenames(string &infname, string &outfname);

//...............pixel array is global, to avoid stack issues

int pixels[512 * 512] = { 0 };

//...............put your prototypes here...................
bool readPGM(string &infilename, string &type, int &ncols, int &nrows, int &maxval, int pixels[]);
bool savePGM(string infilename, string outfilename, const string &type, const int &ncols, const int &nrows, const int &maxval, int pixels[]);
bool printPGM(string infilename, const string type, const int ncols, const int nrows, const int maxval, int pixels[]);
//..........................................................

int main(void)

{

	string infilename, outfilename;
	// for image:
	string type;
	int ncols = 0, nrows = 0, maxval = 0;

	// get input & output filenames, or bail out if problem
	if (!get_filenames(infilename, outfilename))
	{
		cout << "Error opening input or output file " << endl;
		return 1;
	}

	cout << "reading " << infilename << ", displaying, and copying to " << outfilename << endl;

	// Read the PGM file.  as the code below suggests, set ncols & nrows to zero in the function
	//  and let that be a flag that there is a problem reading the file.
	// Or, you could have your program return a boolean, as
	// get_filenames(...) does, to flag that there was a problem.  If you do, then modify
	// the call to read something like
	// if (!readPGM(...) ) {output error message and exit}

	
	if (!(readPGM(infilename, type, ncols, nrows, maxval, pixels))) {
		cout << "Error! Can not open file!";
		return 1;
	}	
	
	if (ncols*nrows == 0)       // if image array is size 0, problem!
	{
		cout << "error reading file " << infilename << endl;
		return 1;
	}

	// Display the PGM header info and the pixel array

	//not sure if you wanted it twice with this wording, so it was done twice to be safe.


	//...........add your function call to printPGM here!
	printPGM(infilename, type, ncols, nrows, maxval, pixels);

	// Save PGM file
	savePGM(infilename, outfilename, type, ncols, nrows, maxval, pixels);



	//...........add your function call to savePGM here! 


	return 0;
}


bool readPGM(string &infilename, string &type, int &ncols, int &nrows, int &maxval, int pixels[]) {
	//inputs: infilename
	//ouputs: type,ncols,nrows,maxval, pixels
	//opens file and puts values into respective vars.
	ifstream ifs(infilename);
	if (!ifs) {
		printf("error file not open!");
		return false;
	}
	else
	ifs >> type >> ncols >> nrows >> maxval;
	for (int r = 0; r < nrows; r++) {
		for (int c = 0; c < ncols; c++) {
			int ix = r*ncols + c;
			ifs >> pixels[ix];
		}
	}
	ifs.close();

	return true;
}

bool savePGM(string infilename, string outfilename,const string &type, const int &ncols, const int &nrows, const int &maxval, int pixels[]) {
	//inputs: everything
	//outputs: 1 or 0/
	//takes in values, uses readPGM function to get values then puts those values 
	//into file with specified name by user.
	
	ofstream ofs(outfilename);
	if (!ofs) {
		cout << "Error file not open!";
		return false;
	}

	ofs << type << " " << ncols << " " << nrows << " " << maxval << " ";

	for (int r = 0; r < nrows; r++) {
		for (int c = 0; c < ncols; c++) {
			int ix = r*ncols + c;
			ofs << pixels[ix] << " ";
		}
		cout << endl;
	}
	return true;
}

bool printPGM(string infilename, const string type, const int ncols, const int nrows, const int maxval, int pixels[]) {
	//inputs: all the things.
	//outputs: the header and pixels.
	//uses readPGM for help
	//readPGM(infilename, type, ncols, nrows, maxval, pixels);
	ifstream ifs(infilename);
	if (!ifs) {
		cout << "Error can not open file!" << endl;
		return false;
	}
	cout << "The header of the PGM is: " << type << " " << ncols << " " << nrows << " " << maxval << endl;
	cout << "Please press enter to display pixels..";
	system("pause");

	cout << "The pixels in the file are: ";

	for (int r = 0; r < nrows; r++) {
		for (int c = 0; c < ncols; c++) {
			int ix = r*ncols + c;
			cout << pixels[ix] << "\t";
			if ((c) % 10 == 0)
				cout << "\n";
		}
		cout << endl;
	}
	return true;
}


// get input & output filenames, verify input file can be read
// outputs:  infname and outfname, both strings.
// return value:
//      true        if we can open the input & output files properly
//      false       if there is a problem.  This allows the calling code
//                      to decide the appropriate response if there is a problem.
bool get_filenames(string &infname, string &outfname)
{
	cout << "Enter the name of the PGM file: ";
	cin >> infname;
	ifstream ifs(infname.c_str());   // verify file is readable
	if (!ifs)
	{
		cout << "Error:  can't open " << infname << " for reading " << endl;
		return(false);    // bail out if problem.
	}
	ifs.close();

	cout << "enter the outputname to copy the PGM to: ";
	cin >> outfname;
	ofstream ofs(outfname.c_str());   // verify we can write to the output file
	if (!ofs)
	{
		return false;    // bail out if problem.
	}
	ofs.close();    // close it.  you'll open it later in savePGM
	return true;
}
