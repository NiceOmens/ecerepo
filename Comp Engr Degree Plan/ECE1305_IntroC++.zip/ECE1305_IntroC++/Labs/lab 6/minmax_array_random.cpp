/*

Worked with: No one
Class: ECE 1305-04
3/23/2017

LAB 06, part 2

Description:
Takes 10 inputs from user and puts that in an array. Then finds min and max element of that 
array, as well as the average.

Also generates 25 random values for an array, and finds the min,max and avg.
*/

#include<iostream>
#include<iomanip>

using namespace std;

//......................add your prototypes here................
int min_element(const int array[], const int &sizeI);

int max_element(const int array[], const int &sizeO);

void query_for_array(int array[], int &sizE);

int array_average(int array[], int &length);

void array_stats(int array[], int &size);
//..............................................................


int main(void)
{

	//adding this so avg is visible to user
	int avg = 0;
	//

	int n = 10;
	int myarray[10];
	int rand_array[25];  // for part 2d
	int val = 0;
	int mymin, mymax;

	

	/*
		for (int i = 0; i < n; i++)
	{
		cout << "Enter the element No. " << i << "of the array ";
		cin >> val;
		myarray[i] = val;
	}
	*/

	// for part 2b, replace the above loop with a this function call, and write the function:

	query_for_array(myarray, n);

	// for part 2c, add a function to calculate the average of an array, and a function to return all 3 values (min, max and average).

	mymin = min_element(myarray, n);
	mymax = max_element(myarray, n);

	//added this so average is visible to user
	avg = array_average(myarray, n);
	cout << "The average of the array is " << avg << endl;

	cout << "The minimum element of the array is " << mymin << endl;

	cout << "The maximum element of the array is " << mymax << endl;

	// for part 2d, add code here to fill rand_array[] with 25 random numbers, and then use your stats function
	// to find the min, max and average

	//area for part 2d
	
	//variables for values needed to output
	int randAvg = 0;
	int randMax = 0;
	int randMin = 0;
	int randSize = 25; // size of rand array

	//for RNG
	srand(time(0));
	for (int i = 0; i < randSize; i++) {
		rand_array[i] = rand();
	}

	//calls to functions
	randAvg = array_average(rand_array, randSize);
	randMin = min_element(rand_array, randSize);
	randMax = max_element(rand_array, randSize);

	//outputs for rand_array values
	cout << "The average of rand_array is " << randAvg << endl;

	cout << "The minimum element of rand_array is " << randMin << endl;

	cout << "The maximum element of rand_array is " << randMax << endl;






	return 0;
}
//.......................add your functions here....................


int min_element(const int array[], const int &sizeI) {
	//Inputs: array, sizeI
	//Outputs: smallest
	//takes an array of size n and returns its min value element
	int smallest = array[0];
	for(int i = 0; i < sizeI; i++){
		if (array[i] < smallest) {
			smallest = array[i];
		}

	}
	return smallest;
}

int max_element(const int array[], const int &sizeO) {
	//Inputs: array, sizeO
	//Outputs: largest
	//takes an array of size n and returns its max value element
	int largest = array[0];
	for (int i = 0; i < sizeO; i++) {
		if (array[i] > largest) {
			largest = array[i];
		}
	}


	return largest;
}


void query_for_array(int array[], int &sizE) {
	//Inputs: none, type void.
	//Outputs: array, sizeE.
	//requests from user array values of size n = 10 from user.
	int val = 0;
	for (int i = 0; i < sizE; i++)
	{
		cout << "Enter the element No. " << i << "of the array ";
		cin >> val;
		array[i] = val;
	}

}

int array_average(int array[], int &length) {
	//input: array, length
	//outputs: average
	//finds average of given array and length
	int average = 0;
	int sum = 0;
	int temp = length;
	for (int i = 0; i < temp; i++) {
		 sum = sum + array[i];
	}
	average = (sum / temp);

	return average;
}

void array_stats(int array[], int &size) {
	//inputs: array, size
	//outputs: none, type void
	//calls min_element, max_element, and array_average to find 
	//respective values.
	int min = min_element(array, size);
	int max = max_element(array, size);
	int average = array_average(array, size);
	return;
}